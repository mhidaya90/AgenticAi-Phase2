'''
Multi-Agent Household Energy Requirement Calculator & Advisor
==============================================================

Flow:
  User inputs (household profile)
    --> Agent 1 : Profile Agent           - house type, area, bedrooms, floors, city tier, climate zone
    --> Agent 2 : Occupancy Agent         - adults, children
    --> Agent 3 : Appliance Agent         - ACs, fans, lighting, water heater, fridge, MW, dishwasher, WM, TVs, PCs
    --> Agent 4 : Envelope Agent          - insulation, windows, roof
    --> Agent 5 : Renewable Agent         - solar panels, battery storage
    --> Agent 6 : Consumption Agent       - daily / monthly kWh, peak load (deterministic appliance maths)
    --> Agent 7 : Recommendation Agent    - peer benchmark + solar payback + LLM-prioritised efficiency tips

LangGraph Routing:
  profile --> occupancy --> appliance --> envelope --> renewable --> consumption --> recommendation --> END

The benchmarking dataset is household_energy_requirement.csv (1,000 profiles across
5 climate zones, 3 city tiers, multiple house types).
'''

import os, json
import pandas as pd
import streamlit as st
from openai import OpenAI
from typing import TypedDict
from langgraph.graph import StateGraph, END
from dotenv import load_dotenv, find_dotenv

# Walk up to find a .env 
load_dotenv(find_dotenv(usecwd=True))


CLIENT          = None
CLIENT_INIT_ERR = None
def _get_client():
    global CLIENT, CLIENT_INIT_ERR
    if CLIENT is not None or CLIENT_INIT_ERR is not None:
        return CLIENT
    try:
        CLIENT = OpenAI()
    except Exception as e:
        CLIENT_INIT_ERR = str(e)
    return CLIENT

# -----------------------------------------------
# File paths
# -----------------------------------------------
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
DATASET_CSV = os.path.join(BASE_DIR, "household_energy_requirement.csv")

# -----------------------------------------------
# LangGraph State
# -----------------------------------------------
class HouseholdState(TypedDict):
    user_input    : str
    session_state : dict     # carries every agent's output

# -----------------------------------------------
# Helper : OpenAI call (with graceful fallback)
# -----------------------------------------------
def GetResponse(system_prompt, user_prompt):
    ret    = {"status": "", "message": ""}
    client = _get_client()
    if client is None:
        ret["status"]  = "EXCEPTION"
        ret["message"] = f"OpenAI client unavailable: {CLIENT_INIT_ERR}"
        return ret
    try:
        resp = client.chat.completions.create(
            model    = "gpt-4o",
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": user_prompt}
            ]
        )
        ret["status"]  = "SUCCESS"
        ret["message"] = resp.choices[0].message.content
    except Exception as e:
        ret["status"]  = "EXCEPTION"
        ret["message"] = str(e)
    return ret

# ===============================================
# Agent 1 : Profile Agent
# ===============================================
def profile_agent(state: HouseholdState):
    """Collect house type, floor area, bedrooms, floors, city tier, climate zone."""
    s       = dict(state.get("session_state", {}))
    inputs  = s.get("inputs", {})

    s["profile"] = {
        "house_type"      : inputs.get("house_type"),
        "num_bedrooms"    : int(inputs.get("num_bedrooms", 0)),
        "floor_area_sqft" : int(inputs.get("floor_area_sqft", 0)),
        "num_floors"      : int(inputs.get("num_floors", 1)),
        "city_tier"       : inputs.get("city_tier"),
        "climate_zone"    : inputs.get("climate_zone"),
    }
    s["profile_status"] = "SUCCESS"
    return {"session_state": s}

# ===============================================
# Agent 2 : Occupancy Agent
# ===============================================
def occupancy_agent(state: HouseholdState):
    """Record number of adults and children."""
    s      = dict(state.get("session_state", {}))
    inputs = s.get("inputs", {})

    adults   = int(inputs.get("num_adults",   0))
    children = int(inputs.get("num_children", 0))

    s["occupancy"] = {
        "num_adults"    : adults,
        "num_children"  : children,
        "num_occupants" : adults + children
    }
    s["occupancy_status"] = "SUCCESS"
    return {"session_state": s}

# ===============================================
# Agent 3 : Appliance Agent
# ===============================================
def appliance_agent(state: HouseholdState):
    """Inventory every major energy-consuming appliance."""
    s      = dict(state.get("session_state", {}))
    inputs = s.get("inputs", {})

    s["appliances"] = {
        "has_ac"                       : int(inputs.get("has_ac", 0)),
        "num_ac_units"                 : int(inputs.get("num_ac_units", 0)),
        "ac_star_rating"               : int(inputs.get("ac_star_rating", 0)),
        "ac_usage_hrs_per_day"         : float(inputs.get("ac_usage_hrs_per_day", 0)),
        "num_ceiling_fans"             : int(inputs.get("num_ceiling_fans", 0)),
        "num_led_bulbs"                : int(inputs.get("num_led_bulbs", 0)),
        "num_cfl_bulbs"                : int(inputs.get("num_cfl_bulbs", 0)),
        "num_incandescent_bulbs"       : int(inputs.get("num_incandescent_bulbs", 0)),
        "avg_lighting_hrs_per_day"     : float(inputs.get("avg_lighting_hrs_per_day", 0)),
        "water_heater_type"            : inputs.get("water_heater_type", "None"),
        "water_heater_capacity_L"      : int(inputs.get("water_heater_capacity_L", 0)),
        "water_heater_usage_hrs_per_day": float(inputs.get("water_heater_usage_hrs_per_day", 0)),
        "has_refrigerator"             : int(inputs.get("has_refrigerator", 0)),
        "fridge_capacity_L"            : int(inputs.get("fridge_capacity_L", 0)),
        "fridge_star_rating"           : int(inputs.get("fridge_star_rating", 0)),
        "has_microwave"                : int(inputs.get("has_microwave", 0)),
        "has_electric_stove"           : int(inputs.get("has_electric_stove", 0)),
        "has_dishwasher"               : int(inputs.get("has_dishwasher", 0)),
        "dishwasher_cycles_per_week"   : int(inputs.get("dishwasher_cycles_per_week", 0)),
        "has_washing_machine"          : int(inputs.get("has_washing_machine", 0)),
        "washing_machine_type"         : inputs.get("washing_machine_type", "None"),
        "washing_cycles_per_week"      : int(inputs.get("washing_cycles_per_week", 0)),
        "has_dryer"                    : int(inputs.get("has_dryer", 0)),
        "num_tvs"                      : int(inputs.get("num_tvs", 0)),
        "tv_screen_size_inch"          : int(inputs.get("tv_screen_size_inch", 0)),
        "tv_usage_hrs_per_day"         : float(inputs.get("tv_usage_hrs_per_day", 0)),
        "num_computers"                : int(inputs.get("num_computers", 0)),
        "computer_usage_hrs_per_day"   : float(inputs.get("computer_usage_hrs_per_day", 0)),
    }
    s["appliance_status"] = "SUCCESS"
    return {"session_state": s}

# ===============================================
# Agent 4 : Envelope Agent
# ===============================================
def envelope_agent(state: HouseholdState):
    """Capture insulation, window and roof characteristics."""
    s      = dict(state.get("session_state", {}))
    inputs = s.get("inputs", {})

    s["envelope"] = {
        "insulation_quality" : inputs.get("insulation_quality"),
        "window_type"        : inputs.get("window_type"),
        "roof_type"          : inputs.get("roof_type"),
    }
    s["envelope_status"] = "SUCCESS"
    return {"session_state": s}

# ===============================================
# Agent 5 : Renewable Agent
# ===============================================
def renewable_agent(state: HouseholdState):
    """Record rooftop solar and battery storage installations."""
    s      = dict(state.get("session_state", {}))
    inputs = s.get("inputs", {})

    s["renewable"] = {
        "has_solar_panels"     : int(inputs.get("has_solar_panels", 0)),
        "solar_capacity_kWp"   : float(inputs.get("solar_capacity_kWp", 0)),
        "has_battery_storage"  : int(inputs.get("has_battery_storage", 0)),
        "battery_capacity_kWh" : float(inputs.get("battery_capacity_kWh", 0)),
    }
    s["renewable_status"] = "SUCCESS"
    return {"session_state": s}

# ===============================================
# Agent 6 : Consumption Agent
# ===============================================
# Coefficients chosen so totals stay within ~20% of the reference dataset's
# daily_energy_consumption_kWh column for a wide range of profiles.
AC_WATTS_BY_STAR     = {1: 1800, 2: 1600, 3: 1400, 4: 1250, 5: 1100}
FRIDGE_KWH_BY_STAR   = {1: 2.0,  2: 1.7,  3: 1.4,  4: 1.1,  5: 0.85}    # per-day baseline for 250 L
WATER_HEATER_WATTS   = {
    "Electric"      : 2000,
    "Solar + Backup": 500,
    "Gas"           : 0,
    "Heat Pump"     : 800,
    "None"          : 0,
}
WASHING_KWH_PER_CYCLE = {
    "Top Load"      : 1.5,
    "Front Load"    : 1.0,
    "Semi-Automatic": 0.8,
    "None"          : 0,
}

def _appliance_breakdown(appl):
    """Return a dict of appliance -> kWh/day, plus a peak-load estimate in kW."""
    daily = {}
    peak_w = 0  # for peak load aggregation

    # --- AC ---
    if appl["has_ac"] and appl["num_ac_units"] > 0:
        watt = AC_WATTS_BY_STAR.get(appl["ac_star_rating"], 1500)
        kwh  = appl["num_ac_units"] * watt * appl["ac_usage_hrs_per_day"] / 1000
        daily["AC"] = round(kwh, 2)
        peak_w     += appl["num_ac_units"] * watt

    # --- Ceiling fans (assume 8 hrs/day at 75 W) ---
    if appl["num_ceiling_fans"] > 0:
        kwh = appl["num_ceiling_fans"] * 75 * 8 / 1000
        daily["Ceiling Fans"] = round(kwh, 2)
        peak_w               += appl["num_ceiling_fans"] * 75

    # --- Lighting ---
    light_w_total = (
        appl["num_led_bulbs"]          *  9
        + appl["num_cfl_bulbs"]          * 14
        + appl["num_incandescent_bulbs"] * 60
    )
    if light_w_total > 0:
        kwh = light_w_total * appl["avg_lighting_hrs_per_day"] / 1000
        daily["Lighting"] = round(kwh, 2)
        peak_w           += light_w_total

    # --- Water heater ---
    wh_watt = WATER_HEATER_WATTS.get(appl["water_heater_type"], 0)
    if wh_watt > 0 and appl["water_heater_usage_hrs_per_day"] > 0:
        kwh = wh_watt * appl["water_heater_usage_hrs_per_day"] / 1000
        daily["Water Heater"] = round(kwh, 2)
        peak_w               += wh_watt

    # --- Refrigerator (capacity- and star-scaled) ---
    if appl["has_refrigerator"]:
        base = FRIDGE_KWH_BY_STAR.get(appl["fridge_star_rating"], 1.4)
        kwh  = base * max(appl["fridge_capacity_L"], 100) / 250
        daily["Refrigerator"] = round(kwh, 2)
        peak_w               += 200  # compressor ~200 W

    # --- Microwave / Electric stove ---
    if appl["has_microwave"]:
        daily["Microwave"] = 0.6
        peak_w            += 1200
    if appl["has_electric_stove"]:
        daily["Electric Stove"] = 3.0
        peak_w                 += 2000

    # --- Dishwasher / Washing machine / Dryer ---
    if appl["has_dishwasher"] and appl["dishwasher_cycles_per_week"] > 0:
        daily["Dishwasher"] = round(appl["dishwasher_cycles_per_week"] * 1.5 / 7, 2)
        peak_w             += 1500

    if appl["has_washing_machine"] and appl["washing_cycles_per_week"] > 0:
        per_cycle = WASHING_KWH_PER_CYCLE.get(appl["washing_machine_type"], 1.2)
        daily["Washing Machine"] = round(
            appl["washing_cycles_per_week"] * per_cycle / 7, 2
        )
        peak_w                  += 1000

    if appl["has_dryer"]:
        # tied to washing cycles if any, else assume 3/week
        cycles = appl["washing_cycles_per_week"] or 3
        daily["Dryer"] = round(cycles * 2.5 / 7, 2)
        peak_w        += 2500

    # --- TVs ---
    if appl["num_tvs"] > 0 and appl["tv_screen_size_inch"] > 0:
        watt = appl["tv_screen_size_inch"] * 1.2  # ~50 W for 42" LED
        kwh  = appl["num_tvs"] * watt * appl["tv_usage_hrs_per_day"] / 1000
        daily["TVs"] = round(kwh, 2)
        peak_w      += appl["num_tvs"] * watt

    # --- Computers ---
    if appl["num_computers"] > 0:
        kwh = appl["num_computers"] * 150 * appl["computer_usage_hrs_per_day"] / 1000
        daily["Computers"] = round(kwh, 2)
        peak_w            += appl["num_computers"] * 150

    # Diversity factor 0.6 — not every load runs at the same instant.
    peak_kw = round(peak_w * 0.6 / 1000, 2)
    return daily, peak_kw

def consumption_agent(state: HouseholdState):
    """Estimate daily/monthly kWh and peak load from appliance inventory."""
    s    = dict(state.get("session_state", {}))
    appl = s.get("appliances", {})

    breakdown, peak_kw = _appliance_breakdown(appl)
    daily_gross        = round(sum(breakdown.values()), 2)

    # Net of self-consumed solar (rule of thumb: ~70% of generation displaces grid).
    ren           = s.get("renewable", {})
    solar_kwp     = ren.get("solar_capacity_kWp", 0) if ren.get("has_solar_panels") else 0
    solar_gen_day = round(solar_kwp * 4.5, 2)         # India avg ~4.5 kWh/kWp/day
    solar_offset  = round(min(daily_gross * 0.7, solar_gen_day * 0.85), 2)
    daily_net     = round(max(daily_gross - solar_offset, 0), 2)

    s["consumption"] = {
        "appliance_breakdown_kWh" : breakdown,
        "daily_gross_kWh"         : daily_gross,
        "monthly_gross_kWh"       : round(daily_gross * 30, 2),
        "solar_generation_kWh_day": solar_gen_day,
        "self_consumed_solar_kWh" : solar_offset,
        "daily_net_kWh"           : daily_net,
        "monthly_net_kWh"         : round(daily_net * 30, 2),
        "peak_load_kW"            : peak_kw,
    }
    s["consumption_status"] = "SUCCESS"
    return {"session_state": s}

# ===============================================
# Agent 7 : Recommendation Agent
# ===============================================
# Indian grid emission factor ~0.82 kg CO2 / kWh, residential tariff ~Rs 7/unit.
GRID_EMISSION_KG_PER_KWH = 0.82
TARIFF_INR_PER_KWH       = 7.0
SOLAR_COST_PER_KWP_INR   = 55_000        # post-subsidy ballpark
SOLAR_GEN_PER_KWP_DAY    = 4.5
SOLAR_LIFETIME_YEARS     = 25

def _peer_benchmark(profile, daily_kwh):
    """Compare this household against peers with the same climate, tier, house type."""
    try:
        df = pd.read_csv(DATASET_CSV)
    except Exception:
        return None

    peers = df[
        (df["climate_zone"] == profile["climate_zone"]) &
        (df["city_tier"]   == profile["city_tier"])   &
        (df["house_type"]  == profile["house_type"])
    ]
    if len(peers) < 5:
        peers = df[df["climate_zone"] == profile["climate_zone"]]
    if len(peers) == 0:
        return None

    series = peers["daily_energy_consumption_kWh"]
    percentile = round((series < daily_kwh).mean() * 100, 1)
    return {
        "peer_count"      : int(len(peers)),
        "peer_mean_kWh"   : round(series.mean(), 2),
        "peer_median_kWh" : round(series.median(), 2),
        "peer_p25_kWh"    : round(series.quantile(0.25), 2),
        "peer_p75_kWh"    : round(series.quantile(0.75), 2),
        "user_percentile" : percentile,   # higher = uses more than peers
    }

def _solar_options(daily_kwh, current_solar_kwp):
    """Payback + savings + lifetime CO2 offset for several capacity options."""
    options = []
    for kwp in [1, 2, 3, 5]:
        if kwp <= current_solar_kwp:
            continue
        gen_day      = kwp * SOLAR_GEN_PER_KWP_DAY
        useful_day   = min(gen_day * 0.85, daily_kwh * 0.7)   # cap by load
        annual_save  = round(useful_day * 365 * TARIFF_INR_PER_KWH, 0)
        capex        = kwp * SOLAR_COST_PER_KWP_INR
        payback_yrs  = round(capex / annual_save, 1) if annual_save > 0 else None
        co2_lifetime = round(useful_day * 365 * SOLAR_LIFETIME_YEARS * GRID_EMISSION_KG_PER_KWH / 1000, 1)
        options.append({
            "capacity_kWp"   : kwp,
            "capex_INR"      : capex,
            "annual_save_INR": annual_save,
            "payback_years"  : payback_yrs,
            "co2_offset_tonnes_25yr": co2_lifetime
        })
    return options

def _rule_based_recommendations(s):
    """Deterministic prioritised list - used when LLM is unreachable."""
    appl    = s["appliances"]
    env     = s["envelope"]
    cons    = s["consumption"]
    recs    = []

    # 1) Incandescent -> LED swap
    if appl["num_incandescent_bulbs"] > 0:
        save = round(
            appl["num_incandescent_bulbs"] * (60 - 9)
            * appl["avg_lighting_hrs_per_day"] * 30 / 1000, 1
        )
        recs.append({
            "priority": 1,
            "action"  : f"Replace {appl['num_incandescent_bulbs']} incandescent bulbs with LEDs",
            "monthly_kWh_saved": save,
            "monthly_INR_saved": round(save * TARIFF_INR_PER_KWH, 0)
        })

    # 2) AC thermostat - assume 24 -> 26 deg = 6% saving per degree
    if cons["appliance_breakdown_kWh"].get("AC", 0) > 0:
        ac_kwh    = cons["appliance_breakdown_kWh"]["AC"]
        save_mon  = round(ac_kwh * 30 * 0.12, 1)
        recs.append({
            "priority": 2,
            "action"  : "Raise AC thermostat from 22 deg C to 24-26 deg C (BEE guidance)",
            "monthly_kWh_saved": save_mon,
            "monthly_INR_saved": round(save_mon * TARIFF_INR_PER_KWH, 0)
        })

    # 3) Electric heater -> solar water heater
    if appl["water_heater_type"] == "Electric":
        wh_kwh    = cons["appliance_breakdown_kWh"].get("Water Heater", 0)
        save_mon  = round(wh_kwh * 30 * 0.75, 1)
        recs.append({
            "priority": 3,
            "action"  : "Switch from electric geyser to solar water heater (with backup)",
            "monthly_kWh_saved": save_mon,
            "monthly_INR_saved": round(save_mon * TARIFF_INR_PER_KWH, 0)
        })

    # 4) Poor insulation
    if env["insulation_quality"] in ("Poor", "Average") and \
       cons["appliance_breakdown_kWh"].get("AC", 0) > 0:
        save_mon = round(cons["appliance_breakdown_kWh"]["AC"] * 30 * 0.15, 1)
        recs.append({
            "priority": 4,
            "action"  : "Improve wall/roof insulation - cuts cooling load ~15%",
            "monthly_kWh_saved": save_mon,
            "monthly_INR_saved": round(save_mon * TARIFF_INR_PER_KWH, 0)
        })

    # 5) Low star fridge swap
    if appl["has_refrigerator"] and appl["fridge_star_rating"] <= 2:
        save_mon = round((FRIDGE_KWH_BY_STAR[appl["fridge_star_rating"]] -
                          FRIDGE_KWH_BY_STAR[5]) * 30, 1)
        recs.append({
            "priority": 5,
            "action"  : "Upgrade to 5-star refrigerator at next replacement cycle",
            "monthly_kWh_saved": save_mon,
            "monthly_INR_saved": round(save_mon * TARIFF_INR_PER_KWH, 0)
        })

    return recs

def recommendation_agent(state: HouseholdState):
    """Peer benchmark + solar payback + LLM-prioritised efficiency recommendations."""
    s = dict(state.get("session_state", {}))

    profile  = s.get("profile",  {})
    cons     = s.get("consumption", {})
    ren      = s.get("renewable",   {})

    benchmark   = _peer_benchmark(profile, cons.get("daily_gross_kWh", 0))
    solar_opts  = _solar_options(cons.get("daily_gross_kWh", 0),
                                 ren.get("solar_capacity_kWp", 0)
                                 if ren.get("has_solar_panels") else 0)
    rule_recs   = _rule_based_recommendations(s)

    # LLM-driven narrative + ranking
    system_prompt = (
        "You are a residential energy efficiency advisor for Indian households. "
        "Given the household profile, appliance mix, envelope, current consumption, "
        "peer benchmark, and rule-based saving candidates, produce a short, "
        "prioritised, quantified action plan. Use plain language. Cite kWh/month "
        "and INR/month savings for each action. Then add a 2-3 line summary of the "
        "solar business case using the supplied capacity options."
    )
    user_prompt = json.dumps({
        "profile"           : profile,
        "envelope"          : s.get("envelope", {}),
        "consumption"       : cons,
        "renewable"         : ren,
        "peer_benchmark"    : benchmark,
        "rule_based_saves"  : rule_recs,
        "solar_capacity_options": solar_opts
    }, default=str, indent=2)

    resp = GetResponse(system_prompt, user_prompt)
    if resp["status"] == "SUCCESS":
        narrative = resp["message"]
    else:
        narrative = "LLM unreachable - showing rule-based recommendations only."

    s["recommendation"] = {
        "peer_benchmark"        : benchmark,
        "solar_capacity_options": solar_opts,
        "rule_based"            : rule_recs,
        "llm_narrative"         : narrative,
    }
    s["recommendation_status"] = "SUCCESS"
    return {"session_state": s}

# ===============================================
# Build LangGraph
# ===============================================
def BuildGraph():
    builder = StateGraph(HouseholdState)

    builder.add_node("profile_agent",        profile_agent)
    builder.add_node("occupancy_agent",      occupancy_agent)
    builder.add_node("appliance_agent",      appliance_agent)
    builder.add_node("envelope_agent",       envelope_agent)
    builder.add_node("renewable_agent",      renewable_agent)
    builder.add_node("consumption_agent",    consumption_agent)
    builder.add_node("recommendation_agent", recommendation_agent)

    builder.set_entry_point("profile_agent")
    builder.add_edge("profile_agent",        "occupancy_agent")
    builder.add_edge("occupancy_agent",      "appliance_agent")
    builder.add_edge("appliance_agent",      "envelope_agent")
    builder.add_edge("envelope_agent",       "renewable_agent")
    builder.add_edge("renewable_agent",      "consumption_agent")
    builder.add_edge("consumption_agent",    "recommendation_agent")
    builder.add_edge("recommendation_agent", END)

    return builder.compile()

GRAPH = BuildGraph()

# ===============================================
# Streamlit defaults
# ===============================================
_defaults = {
    "stage"  : "profile",   # profile | occupancy | appliance | envelope | renewable | result
    "inputs" : {},
    "result" : None,
}
for k, v in _defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ===============================================
# UI helpers
# ===============================================
def Spaces():
    st.markdown(
        "<style>.block-container{padding-top:2rem;} h1{margin-top:1rem;}</style>",
        unsafe_allow_html=True
    )

def progress_bar():
    stages = ["profile", "occupancy", "appliance", "envelope", "renewable", "result"]
    labels = [
        "1. Profile", "2. Occupancy", "3. Appliances",
        "4. Envelope", "5. Renewables", "6. Energy Plan"
    ]
    current = st.session_state["stage"]
    idx     = stages.index(current) if current in stages else 0
    cols    = st.columns(len(labels))
    for i, (col, lab) in enumerate(zip(cols, labels)):
        if   i < idx : col.success(lab)
        elif i == idx: col.info(f"**{lab}**")
        else         : col.write(lab)
    st.markdown("---")

# -----------------------------------------------
# Stage 1 - Profile
# -----------------------------------------------
def stage_profile():
    st.subheader("Step 1 - Household Profile")
    inp = st.session_state["inputs"]

    c1, c2, c3 = st.columns(3)
    inp["house_type"]      = c1.selectbox("House Type",
        ["Apartment", "Row House", "Independent House", "Villa", "Bungalow"],
        index=0)
    inp["num_bedrooms"]    = c2.number_input("Bedrooms",    1, 10, 2)
    inp["num_floors"]      = c3.number_input("Floors",      1, 5, 1)
    inp["floor_area_sqft"] = c1.number_input("Floor area (sqft)", 200, 10000, 1000, step=50)
    inp["city_tier"]       = c2.selectbox("City Tier", ["Tier 1", "Tier 2", "Tier 3"], index=1)
    inp["climate_zone"]    = c3.selectbox("Climate Zone",
        ["Hot & Humid", "Hot & Dry", "Composite", "Temperate", "Cold"], index=2)

    if st.button("Proceed to Occupancy ->"):
        st.session_state["stage"] = "occupancy"
        st.rerun()

# -----------------------------------------------
# Stage 2 - Occupancy
# -----------------------------------------------
def stage_occupancy():
    st.subheader("Step 2 - Occupancy")
    inp = st.session_state["inputs"]

    c1, c2 = st.columns(2)
    inp["num_adults"]   = c1.number_input("Adults",   0, 10, 2)
    inp["num_children"] = c2.number_input("Children", 0, 10, 1)

    if st.button("Proceed to Appliances ->"):
        st.session_state["stage"] = "appliance"
        st.rerun()

# -----------------------------------------------
# Stage 3 - Appliances
# -----------------------------------------------
def stage_appliance():
    st.subheader("Step 3 - Appliance Inventory")
    inp = st.session_state["inputs"]

    with st.expander("Cooling & Lighting", expanded=True):
        c1, c2, c3, c4 = st.columns(4)
        inp["has_ac"]                = c1.selectbox("Has AC?",  [0, 1], index=1)
        inp["num_ac_units"]          = c2.number_input("AC units", 0, 10, 1)
        inp["ac_star_rating"]        = c3.selectbox("AC star rating", [0, 1, 2, 3, 4, 5], index=4)
        inp["ac_usage_hrs_per_day"]  = c4.number_input("AC hrs/day", 0.0, 24.0, 6.0, step=0.5)

        c1, c2, c3, c4 = st.columns(4)
        inp["num_ceiling_fans"]         = c1.number_input("Ceiling fans",      0, 20, 4)
        inp["num_led_bulbs"]            = c2.number_input("LED bulbs",          0, 50, 8)
        inp["num_cfl_bulbs"]            = c3.number_input("CFL bulbs",          0, 50, 2)
        inp["num_incandescent_bulbs"]   = c4.number_input("Incandescent bulbs", 0, 50, 1)
        inp["avg_lighting_hrs_per_day"] = st.number_input("Avg lighting hrs/day", 0.0, 24.0, 6.0, step=0.5)

    with st.expander("Kitchen & Laundry", expanded=False):
        c1, c2, c3 = st.columns(3)
        inp["water_heater_type"] = c1.selectbox("Water heater type",
            ["Electric", "Solar + Backup", "Gas", "Heat Pump", "None"], index=0)
        inp["water_heater_capacity_L"]        = c2.number_input("Capacity (L)", 0, 200, 15)
        inp["water_heater_usage_hrs_per_day"] = c3.number_input("Usage hrs/day", 0.0, 24.0, 1.5, step=0.5)

        c1, c2, c3, c4 = st.columns(4)
        inp["has_refrigerator"]   = c1.selectbox("Refrigerator?", [0, 1], index=1)
        inp["fridge_capacity_L"]  = c2.number_input("Fridge capacity (L)", 0, 800, 250)
        inp["fridge_star_rating"] = c3.selectbox("Fridge star rating", [0, 1, 2, 3, 4, 5], index=4)
        inp["has_microwave"]      = c4.selectbox("Microwave?", [0, 1], index=1)

        c1, c2, c3 = st.columns(3)
        inp["has_electric_stove"]         = c1.selectbox("Electric stove?", [0, 1], index=0)
        inp["has_dishwasher"]             = c2.selectbox("Dishwasher?",     [0, 1], index=0)
        inp["dishwasher_cycles_per_week"] = c3.number_input("Dishwasher cycles/week", 0, 21, 0)

        c1, c2, c3, c4 = st.columns(4)
        inp["has_washing_machine"]     = c1.selectbox("Washing machine?", [0, 1], index=1)
        inp["washing_machine_type"]    = c2.selectbox("WM type",
            ["Top Load", "Front Load", "Semi-Automatic", "None"], index=0)
        inp["washing_cycles_per_week"] = c3.number_input("WM cycles/week", 0, 21, 5)
        inp["has_dryer"]               = c4.selectbox("Dryer?", [0, 1], index=0)

    with st.expander("Entertainment & Computing", expanded=False):
        c1, c2, c3 = st.columns(3)
        inp["num_tvs"]             = c1.number_input("TVs", 0, 10, 1)
        inp["tv_screen_size_inch"] = c2.number_input("TV size (inch)", 0, 100, 42)
        inp["tv_usage_hrs_per_day"]= c3.number_input("TV hrs/day", 0.0, 24.0, 4.0, step=0.5)

        c1, c2 = st.columns(2)
        inp["num_computers"]              = c1.number_input("Computers", 0, 10, 1)
        inp["computer_usage_hrs_per_day"] = c2.number_input("PC hrs/day", 0.0, 24.0, 6.0, step=0.5)

    if st.button("Proceed to Envelope ->"):
        st.session_state["stage"] = "envelope"
        st.rerun()

# -----------------------------------------------
# Stage 4 - Envelope
# -----------------------------------------------
def stage_envelope():
    st.subheader("Step 4 - Building Envelope")
    inp = st.session_state["inputs"]

    c1, c2, c3 = st.columns(3)
    inp["insulation_quality"] = c1.selectbox("Insulation quality",
        ["Poor", "Average", "Good", "Excellent"], index=2)
    inp["window_type"] = c2.selectbox("Window type",
        ["Single Pane", "Double Pane", "Triple Pane"], index=1)
    inp["roof_type"]   = c3.selectbox("Roof type",
        ["Flat RCC", "Sloped Tiled", "Metal Sheet", "Green Roof", "Thatch"], index=0)

    if st.button("Proceed to Renewables ->"):
        st.session_state["stage"] = "renewable"
        st.rerun()

# -----------------------------------------------
# Stage 5 - Renewables
# -----------------------------------------------
def stage_renewable():
    st.subheader("Step 5 - Renewable Energy Assets")
    inp = st.session_state["inputs"]

    c1, c2 = st.columns(2)
    inp["has_solar_panels"]   = c1.selectbox("Rooftop solar installed?", [0, 1], index=0)
    inp["solar_capacity_kWp"] = c2.number_input("Solar capacity (kWp)", 0.0, 50.0, 0.0, step=0.5)

    c1, c2 = st.columns(2)
    inp["has_battery_storage"]  = c1.selectbox("Battery storage?", [0, 1], index=0)
    inp["battery_capacity_kWh"] = c2.number_input("Battery capacity (kWh)", 0.0, 50.0, 0.0, step=0.5)

    if st.button("Run Energy Analysis ->"):
        with st.spinner("Agents are computing your energy plan..."):
            res = GRAPH.invoke({
                "user_input"   : "",
                "session_state": {"inputs": dict(inp)}
            })
            st.session_state["result"] = res["session_state"]
            st.session_state["stage"]  = "result"
        st.rerun()

# -----------------------------------------------
# Stage 6 - Result
# -----------------------------------------------
def stage_result():
    st.subheader("Step 6 - Your Energy Plan")
    s = st.session_state["result"]
    if not s:
        st.error("No result computed. Please restart.")
        return

    cons   = s.get("consumption",    {})
    rec    = s.get("recommendation", {})
    bench  = rec.get("peer_benchmark")

    # --- headline KPIs ---
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Daily gross",   f"{cons.get('daily_gross_kWh', 0):.1f} kWh")
    c2.metric("Monthly gross", f"{cons.get('monthly_gross_kWh', 0):.0f} kWh")
    c3.metric("Peak load",     f"{cons.get('peak_load_kW', 0):.2f} kW")
    c4.metric("Est. monthly bill",
              f"Rs {cons.get('monthly_gross_kWh', 0) * TARIFF_INR_PER_KWH:,.0f}")

    # --- appliance breakdown ---
    st.markdown("### Appliance-level breakdown (kWh/day)")
    bdf = pd.DataFrame(
        list(cons.get("appliance_breakdown_kWh", {}).items()),
        columns=["Appliance", "kWh/day"]
    ).sort_values("kWh/day", ascending=False)
    st.dataframe(bdf, use_container_width=True)
    if not bdf.empty:
        st.bar_chart(bdf.set_index("Appliance"))

    # --- peer benchmark ---
    if bench:
        st.markdown("### Peer benchmark (same climate / tier / house type)")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Peers compared",    f"{bench['peer_count']}")
        c2.metric("Peer median kWh/d", f"{bench['peer_median_kWh']:.1f}")
        c3.metric("Peer mean kWh/d",   f"{bench['peer_mean_kWh']:.1f}")
        c4.metric("Your percentile",   f"{bench['user_percentile']:.0f} %",
                  help="Higher = uses more than peers")

    # --- solar options ---
    opts = rec.get("solar_capacity_options", [])
    if opts:
        st.markdown("### Rooftop solar - capacity options")
        st.dataframe(pd.DataFrame(opts), use_container_width=True)

    # --- rule-based recs ---
    rb = rec.get("rule_based", [])
    if rb:
        st.markdown("### Quantified efficiency actions")
        st.dataframe(pd.DataFrame(rb).sort_values("priority"),
                     use_container_width=True)

    # --- LLM narrative ---
    st.markdown("### Personalised advisor note")
    st.markdown(rec.get("llm_narrative", "_no narrative_"))

    st.markdown("---")
    if st.button("Start Over"):
        for k, v in _defaults.items():
            st.session_state[k] = v if not isinstance(v, dict) else {}
        st.rerun()

# ===============================================
# Main menu
# ===============================================
def mainmenu():
    progress_bar()
    stage = st.session_state["stage"]
    if   stage == "profile"   : stage_profile()
    elif stage == "occupancy" : stage_occupancy()
    elif stage == "appliance" : stage_appliance()
    elif stage == "envelope"  : stage_envelope()
    elif stage == "renewable" : stage_renewable()
    elif stage == "result"    : stage_result()

def main():
    st.set_page_config(page_title="Household Energy Advisor",
                       page_icon="?", layout="wide")
    st.title("Household Energy Requirement Calculator & Advisor")
    st.caption("Multi-Agent Framework powered by LangGraph + OpenAI GPT-4o")
    Spaces()
    mainmenu()

main()
