# household_energy_dashboard.py
# Run: streamlit run household_energy_dashboard.py

import os, math, datetime, random
from typing import Dict, Any, List

import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from langgraph.graph import StateGraph, END
from openai import OpenAI
from typing import TypedDict

# ─────────────────────────────────────────────────────────────────────────────
# 0. Page config
# ─────────────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Household Energy Advisor",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
  [data-testid="stSidebar"] { background: #0f172a; }
  [data-testid="stSidebar"] * { color: #e2e8f0 !important; }
  [data-testid="stSidebar"] .stSelectbox label,
  [data-testid="stSidebar"] .stSlider label { color: #94a3b8 !important; font-size:12px; }
  .metric-card {
    background: #1e293b; border-radius: 12px;
    padding: 1rem 1.25rem; margin-bottom: 8px;
  }
  .metric-card .label { font-size:12px; color:#94a3b8; margin-bottom:4px; }
  .metric-card .value { font-size:24px; font-weight:700; color:#f1f5f9; }
  .metric-card .delta { font-size:12px; margin-top:4px; }
  .agent-card {
    background:#1e293b; border-left: 4px solid #3b82f6;
    border-radius: 8px; padding: 12px 16px; margin-bottom: 10px;
  }
  .agent-card.active  { border-left-color: #22c55e; }
  .agent-card.done    { border-left-color: #64748b; }
  .agent-title { font-weight:700; font-size:14px; color:#f1f5f9; }
  .agent-task  { font-size:12px; color:#94a3b8; margin-top:2px; }
  .tool-badge {
    display:inline-block; background:#0f172a;
    color:#7dd3fc; font-size:11px; border-radius:4px;
    padding:2px 8px; margin:3px 3px 0 0;
  }
  .log-line { font-size:12px; color:#94a3b8; font-family:monospace; }
  .log-line .ts { color:#475569; }
  .log-line .msg { color:#cbd5e1; }
  div.stButton > button {
    width:100%; background:#3b82f6; color:white;
    border:none; border-radius:8px;
    padding:0.6rem; font-weight:600; font-size:15px;
  }
  div.stButton > button:hover { background:#2563eb; }
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# 1. Setup
# ─────────────────────────────────────────────────────────────────────────────
client = OpenAI()

DATA_PATH = r"C:\cts\multi-agent\dataset\household_energy_requirement.csv"
DATASET   = pd.read_csv(DATA_PATH)

ELECTRICITY_TARIFF = 7.50
PEAK_SUN_HOURS     = 5.0
SOLAR_COST_PER_KWP = 65_000
SOLAR_LIFE_YEARS   = 25

CLIMATE_FACTORS    = {"Hot & Humid":1.15,"Hot & Dry":1.12,"Composite":1.05,"Temperate":1.00,"Cold":1.08}
INSULATION_FACTORS = {"Poor":1.15,"Average":1.08,"Good":1.02,"Excellent":0.95}

# ─────────────────────────────────────────────────────────────────────────────
# 2. State
# ─────────────────────────────────────────────────────────────────────────────
class HouseholdEnergyState(TypedDict):
    log: List[str]
    house_type: str;   climate_zone: str
    num_bedrooms: int; city_tier: str
    profile: Dict[str, Any]
    appliance_breakdown: Dict[str, float]
    gross_consumption_kwh: float
    climate_factor: float;  insulation_factor: float
    adjusted_consumption_kwh: float
    solar_generation_kwh: float; net_grid_kwh: float
    monthly_bill_inr: float;     benchmark: Dict[str, Any]
    solar_roi: Dict[str, Any];   recommendations: str
    final_report: str

def LogMessage(msg):
    ts = datetime.datetime.now().strftime("%H:%M:%S")
    return f"[{ts}] {msg}"

def get_profile(house_type, climate_zone, num_bedrooms, city_tier):
    df = DATASET[
        (DATASET.house_type==house_type)&(DATASET.climate_zone==climate_zone)&
        (DATASET.num_bedrooms==num_bedrooms)&(DATASET.city_tier==city_tier)
    ]
    if df.empty:
        df = DATASET[(DATASET.house_type==house_type)&
                     (DATASET.climate_zone==climate_zone)&
                     (DATASET.num_bedrooms==num_bedrooms)]
    selected = random.randint(1, len(df))
    return df.iloc[selected-1].to_dict() if not df.empty else None

# ─────────────────────────────────────────────────────────────────────────────
# 3. Tools
# ─────────────────────────────────────────────────────────────────────────────
def FetchProfile(house_type, climate_zone, num_bedrooms, city_tier):
    row = get_profile(house_type, climate_zone, num_bedrooms, city_tier)
    return row if row else {"error": "No matching profile found"}

def EstimateGrossConsumption(profile):
    ac          = profile["num_ac_units"]*1.5*profile["ac_usage_hrs_per_day"] if profile["has_ac"] else 0
    fans        = profile["num_ceiling_fans"]*0.075*12
    lighting    = (profile["num_led_bulbs"]*0.009+profile["num_cfl_bulbs"]*0.015+
                   profile["num_incandescent_bulbs"]*0.06)*profile["avg_lighting_hrs_per_day"]
    wh_kw       = {"Electric Geyser":2.0,"Solar + Backup":0.5}.get(profile["water_heater_type"],1.0)
    water_heater= wh_kw*profile["water_heater_usage_hrs_per_day"]
    fridge      = profile["fridge_capacity_L"]*0.00035*24 if profile["has_refrigerator"] else 0
    wm_kw       = {"Front Load":0.8,"Top Load":1.0,"Semi-Automatic":0.6}.get(profile.get("washing_machine_type",""),0)
    washing     = wm_kw*profile["washing_cycles_per_week"]/7.0 if profile["has_washing_machine"] else 0
    dryer       = 2.5*profile["washing_cycles_per_week"]/7.0 if profile["has_dryer"] else 0
    dishwasher  = 1.2*profile["dishwasher_cycles_per_week"]/7.0 if profile["has_dishwasher"] else 0
    microwave   = 0.8*0.5 if profile["has_microwave"] else 0
    stove       = 1.5*1.5 if profile["has_electric_stove"] else 0
    tv          = profile["num_tvs"]*0.08*profile["tv_usage_hrs_per_day"]
    computers   = profile["num_computers"]*0.10*profile["computer_usage_hrs_per_day"]
    bd = {"AC":round(ac,3),"Fans":round(fans,3),"Lighting":round(lighting,3),
          "Water Heater":round(water_heater,3),"Fridge":round(fridge,3),
          "Washing":round(washing,3),"Dryer":round(dryer,3),"Dishwasher":round(dishwasher,3),
          "Microwave":round(microwave,3),"Stove":round(stove,3),
          "TV":round(tv,3),"Computers":round(computers,3)}
    bd["Total"] = round(sum(bd.values()),3)
    return bd

def ApplyAdjustments(gross, climate_zone, insulation_quality):
    cf  = CLIMATE_FACTORS.get(climate_zone,1.0)
    inf = INSULATION_FACTORS.get(insulation_quality,1.0)
    return {"climate_factor":cf,"insulation_factor":inf,
            "adjusted_consumption_kwh":round(gross*cf*inf,3)}

def CalculateNetGridDraw(adjusted, profile):
    solar = round(profile["solar_capacity_kWp"]*PEAK_SUN_HOURS,3) \
            if profile["has_solar_panels"] and profile["solar_capacity_kWp"]>0 else 0.0
    return {"solar_generation_kwh":solar,"net_grid_kwh":round(max(adjusted-solar,0),3)}

def ProjectMonthlyBill(net):
    return round(net*30*ELECTRICITY_TARIFF,2)

def BenchmarkAgainstDataset(house_type, climate_zone, num_bedrooms):
    peers = DATASET[(DATASET.house_type==house_type)&
                    (DATASET.climate_zone==climate_zone)&
                    (DATASET.num_bedrooms==num_bedrooms)]
    if peers.empty: return {"error":"No peers found"}
    daily = peers["daily_energy_consumption_kWh"]
    return {
        "peer_count":int(len(peers)),
        "peer_min":round(float(daily.min()),2),
        "peer_mean":round(float(daily.mean()),2),
        "peer_max":round(float(daily.max()),2),
        "peer_p25":round(float(daily.quantile(0.25)),2),
        "peer_p75":round(float(daily.quantile(0.75)),2),
        "peer_avg_bill":round(float(peers["monthly_energy_consumption_kWh"].mean())*ELECTRICITY_TARIFF,2),
        "pct_solar":round(100.0*peers["has_solar_panels"].sum()/len(peers),1),
        "all_daily":daily.tolist(),
    }

def RunSolarROI(annual_kwh):
    result = {}
    for kwp in [1,3,5,10]:
        gen   = kwp*PEAK_SUN_HOURS*365
        sav   = round(min(gen,annual_kwh)*ELECTRICITY_TARIFF,2)
        cost  = kwp*SOLAR_COST_PER_KWP
        pb    = round(cost/sav,1) if sav>0 else None
        net25 = round(sav*SOLAR_LIFE_YEARS-cost,2)
        result[f"{kwp}kWp"] = {"gen_kwh_yr":round(gen),"savings_inr_yr":sav,
                                "cost_inr":cost,"payback_yrs":pb,"net25":net25}
    return result

def GenerateRecommendations(state):
    p,bm,sr = state["profile"],state["benchmark"],state["solar_roi"]
    sys_p = ("You are an expert household energy advisor for Indian homes. "
             "Give 5 prioritised energy-saving recommendations as a numbered list. "
             "Each: action name | estimated Rs saving/month | one-line justification. "
             "Under 200 words total.")
    usr_p = f"""
Profile: {p.get('house_type')}, {p.get('climate_zone')}, {p.get('num_bedrooms')}BHK, {p.get('city_tier')}
Insulation: {p.get('insulation_quality')} | Window: {p.get('window_type')}
Occupants: {p.get('num_occupants')} | AC: {p.get('num_ac_units')} units {p.get('ac_star_rating')}-star {p.get('ac_usage_hrs_per_day')}h/day
Lighting: {p.get('num_led_bulbs')} LED, {p.get('num_cfl_bulbs')} CFL, {p.get('num_incandescent_bulbs')} incandescent
Water Heater: {p.get('water_heater_type')} {p.get('water_heater_usage_hrs_per_day')}h/day
Solar: {'Yes '+str(p.get('solar_capacity_kWp'))+' kWp' if p.get('has_solar_panels') else 'Not installed'}
Net grid draw: {state['net_grid_kwh']:.2f} kWh/day | Monthly bill: Rs {state['monthly_bill_inr']:,.0f}
Peer mean: {bm.get('peer_mean')} kWh/day | Peers with solar: {bm.get('pct_solar')}%
5kWp solar: payback {sr.get('5kWp',{}).get('payback_yrs')} yrs, saves Rs {sr.get('5kWp',{}).get('savings_inr_yr'):,}/yr
"""
    resp = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role":"system","content":sys_p},{"role":"user","content":usr_p}],
        temperature=0.3)
    return resp.choices[0].message.content.strip()

# ─────────────────────────────────────────────────────────────────────────────
# 4. Agents
# ─────────────────────────────────────────────────────────────────────────────
def Agent_Profile(state):
    log = state["log"]
    log.append(LogMessage("▶ Agent 1: ProfileAgent — Tasks 1-5"))
    log.append(LogMessage("  Tool: FetchProfile"))
    profile = FetchProfile(state["house_type"],state["climate_zone"],state["num_bedrooms"],state["city_tier"])
    log.append(LogMessage("  Tool: FetchProfile: total: " + str(len(profile))))
    if "error" not in profile:
        log.append(LogMessage(f"  ✔ {profile['house_type']}, {profile['climate_zone']}, {profile['num_bedrooms']}BHK"))
        log.append(LogMessage(f"  ✔ Occupants: {profile['num_occupants']} | Solar: {bool(profile['has_solar_panels'])}"))
    else:
        log.append(LogMessage(f"  ✘ {profile['error']}"))
    return {**state,"profile":profile,"log":log}

def Agent_Consumption(state):
    log = state["log"]
    log.append(LogMessage("▶ Agent 2: ConsumptionAgent — Tasks 6-8"))
    p = state["profile"]
    log.append(LogMessage("  Tool: EstimateGrossConsumption"))
    bd = EstimateGrossConsumption(p)
    gross = bd["Total"]
    log.append(LogMessage(f"  ✔ Gross: {gross:.2f} kWh/day"))
    log.append(LogMessage("  Tool: ApplyAdjustments"))
    adj = ApplyAdjustments(gross,p["climate_zone"],p["insulation_quality"])
    log.append(LogMessage(f"  ✔ Adjusted: {adj['adjusted_consumption_kwh']:.2f} kWh/day"))
    log.append(LogMessage("  Tool: CalculateNetGridDraw"))
    net = CalculateNetGridDraw(adj["adjusted_consumption_kwh"],p)
    log.append(LogMessage(f"  ✔ Net grid: {net['net_grid_kwh']:.2f} kWh/day"))
    return {**state,"appliance_breakdown":bd,"gross_consumption_kwh":gross,
            "climate_factor":adj["climate_factor"],"insulation_factor":adj["insulation_factor"],
            "adjusted_consumption_kwh":adj["adjusted_consumption_kwh"],
            "solar_generation_kwh":net["solar_generation_kwh"],
            "net_grid_kwh":net["net_grid_kwh"],"log":log}

def Agent_BillingBenchmark(state):
    log = state["log"]
    log.append(LogMessage("▶ Agent 3: BillingBenchmarkAgent — Tasks 9-10"))
    log.append(LogMessage("  Tool: ProjectMonthlyBill"))
    bill = ProjectMonthlyBill(state["net_grid_kwh"])
    log.append(LogMessage(f"  ✔ Monthly bill: Rs {bill:,.2f}"))
    log.append(LogMessage("  Tool: BenchmarkAgainstDataset"))
    bm = BenchmarkAgainstDataset(state["house_type"],state["climate_zone"],state["num_bedrooms"])
    if "error" not in bm:
        log.append(LogMessage(f"  ✔ Peers: {bm['peer_count']} | Mean: {bm['peer_mean']} kWh/day"))
    return {**state,"monthly_bill_inr":bill,"benchmark":bm,"log":log}

def Agent_SolarROI(state):
    log = state["log"]
    log.append(LogMessage("▶ Agent 4: SolarROIAgent — Task 11"))
    log.append(LogMessage("  Tool: RunSolarROI"))
    roi = RunSolarROI(state["net_grid_kwh"]*365)
    for sz,d in roi.items():
        log.append(LogMessage(f"  ✔ {sz}: payback {d['payback_yrs']} yrs, Rs {d['savings_inr_yr']:,}/yr"))
    return {**state,"solar_roi":roi,"log":log}

def Agent_Recommendations(state):
    log = state["log"]
    log.append(LogMessage("▶ Agent 5: RecommendationAgent — Task 12"))
    log.append(LogMessage("  Tool: GenerateRecommendations (LLM/GPT-4o)"))
    recs = GenerateRecommendations(state)
    log.append(LogMessage("  ✔ Recommendations generated"))
    return {**state,"recommendations":recs,"log":log}

def BuildGraph():
    g = StateGraph(HouseholdEnergyState)
    g.add_node("profile",          Agent_Profile)
    g.add_node("consumption",      Agent_Consumption)
    g.add_node("billing_benchmark",Agent_BillingBenchmark)
    g.add_node("solar_roi",        Agent_SolarROI)
    g.add_node("recommendations",  Agent_Recommendations)
    g.set_entry_point("profile")
    g.add_edge("profile",          "consumption")
    g.add_edge("consumption",      "billing_benchmark")
    g.add_edge("billing_benchmark","solar_roi")
    g.add_edge("solar_roi",        "recommendations")
    g.add_edge("recommendations",  END)
    return g.compile()

# ─────────────────────────────────────────────────────────────────────────────
# 5. Sidebar — Inputs
# ─────────────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚡ Energy Advisor")
    st.markdown("---")
    st.markdown("### Household Profile")

    house_type   = st.selectbox("House type",
        ["Apartment","Row House","Independent House","Villa"])
    climate_zone = st.selectbox("Climate zone",
        ["Hot & Humid","Hot & Dry","Composite","Temperate","Cold"])
    num_bedrooms = st.slider("Bedrooms", 1, 5, 2)
    city_tier    = st.selectbox("City tier", ["Tier 1","Tier 2","Tier 3"])

    st.markdown("---")
    run = st.button("🚀  Run Agents")

    st.markdown("---")
    st.markdown("### Agent Pipeline")
    agents_meta = [
        ("1","ProfileAgent",       "Tasks 1-5", "FetchProfile"),
        ("2","ConsumptionAgent",   "Tasks 6-8", "EstimateGrossConsumption · ApplyAdjustments · CalculateNetGridDraw"),
        ("3","BillingBenchmark",   "Tasks 9-10","ProjectMonthlyBill · BenchmarkAgainstDataset"),
        ("4","SolarROIAgent",      "Task 11",   "RunSolarROI"),
        ("5","RecommendationAgent","Task 12",   "GenerateRecommendations (LLM)"),
    ]
    for num,name,tasks,tools in agents_meta:
        st.markdown(f"""
        <div class="agent-card">
          <div class="agent-title">Agent {num} — {name}</div>
          <div class="agent-task">{tasks}</div>
          {''.join(f'<span class="tool-badge">{t.strip()}</span>' for t in tools.split('·'))}
        </div>""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────────────────────
# 6. Main Panel
# ─────────────────────────────────────────────────────────────────────────────
st.title("⚡ Household Energy Usecase Dashboard")
st.caption("Multi-agent LangGraph System · 5 Agents · 8 Tools · 12 Tasks")

if not run:
    st.info("Configure your household profile in the sidebar and click **Run Agents**.")
    st.stop()

# ── Run graph ────────────────────────────────────────────────────────────────
init: HouseholdEnergyState = {
    "log":[],"house_type":house_type,"climate_zone":climate_zone,
    "num_bedrooms":num_bedrooms,"city_tier":city_tier,
    "profile":{},"appliance_breakdown":{},"gross_consumption_kwh":0.0,
    "climate_factor":1.0,"insulation_factor":1.0,"adjusted_consumption_kwh":0.0,
    "solar_generation_kwh":0.0,"net_grid_kwh":0.0,"monthly_bill_inr":0.0,
    "benchmark":{},"solar_roi":{},"recommendations":"","final_report":"",
}

with st.spinner("Running agent pipeline…"):
    graph  = BuildGraph()
    result = graph.invoke(init)

p   = result["profile"]
bm  = result["benchmark"]
bd  = result["appliance_breakdown"]
roi = result["solar_roi"]

if "error" in p:
    st.error(f"No matching household found: {p['error']}")
    st.stop()

# ── KPI row ──────────────────────────────────────────────────────────────────
st.markdown("### 📊 Key Metrics")
k1,k2,k3,k4,k5 = st.columns(5)

peer_mean = bm.get("peer_mean", 0)
net_kwh   = result["net_grid_kwh"]
vs_pct    = round((net_kwh - peer_mean) / peer_mean * 100, 1) if peer_mean else 0

k1.metric("Gross Consumption",  f"{result['gross_consumption_kwh']:.1f} kWh/day")
k2.metric("Net Grid Draw",      f"{net_kwh:.1f} kWh/day", f"{vs_pct:+.1f}% vs peers")
k3.metric("Monthly Bill",       f"₹{result['monthly_bill_inr']:,.0f}")
k4.metric("Solar Offset",       f"{result['solar_generation_kwh']:.1f} kWh/day")
k5.metric("Peer Avg Bill",      f"₹{bm.get('peer_avg_bill', 0):,.0f}")

st.markdown("---")

# ── Tabs ─────────────────────────────────────────────────────────────────────
tab1,tab2,tab3,tab4,tab5,tab6 = st.tabs([
    "🏠 Profile","⚡ Consumption","📈 Benchmark","☀️ Solar ROI","💡 Recommendations","📋 Audit Log"
])

# ── Tab 1: Profile ────────────────────────────────────────────────────────────
with tab1:
    st.subheader("Household Profile")
    c1,c2,c3 = st.columns(3)
    with c1:
        st.markdown("**Building**")
        st.write(f"Type: {p['house_type']}")
        st.write(f"Bedrooms: {p['num_bedrooms']}")
        st.write(f"Floor area: {p['floor_area_sqft']} sqft")
        st.write(f"Floors: {p['num_floors']}")
        st.write(f"Insulation: {p['insulation_quality']}")
        st.write(f"Window: {p['window_type']}")
        st.write(f"Roof: {p['roof_type']}")
    with c2:
        st.markdown("**Occupancy & Appliances**")
        st.write(f"Occupants: {p['num_occupants']} ({p['num_adults']} adults, {p['num_children']} children)")
        st.write(f"AC units: {p['num_ac_units']} × {p['ac_star_rating']}★ @ {p['ac_usage_hrs_per_day']}h/day")
        st.write(f"Fans: {p['num_ceiling_fans']}")
        st.write(f"LED: {p['num_led_bulbs']} | CFL: {p['num_cfl_bulbs']} | Incandescent: {p['num_incandescent_bulbs']}")
        st.write(f"Water heater: {p['water_heater_type']} ({p['water_heater_capacity_L']}L)")
        st.write(f"Fridge: {p['fridge_capacity_L']}L {p['fridge_star_rating']}★")
        st.write(f"TV: {p['num_tvs']} × {p['tv_screen_size_inch']}\" @ {p['tv_usage_hrs_per_day']}h")
    with c3:
        st.markdown("**Renewables**")
        st.write(f"Solar panels: {'✅' if p['has_solar_panels'] else '❌'} {p['solar_capacity_kWp']} kWp")
        st.write(f"Battery storage: {'✅' if p['has_battery_storage'] else '❌'} {p['battery_capacity_kWh']} kWh")
        st.markdown("**Laundry & Kitchen**")
        st.write(f"Washing machine: {p['washing_machine_type']} × {p['washing_cycles_per_week']}x/wk")
        st.write(f"Dryer: {'✅' if p['has_dryer'] else '❌'}")
        st.write(f"Dishwasher: {'✅' if p['has_dishwasher'] else '❌'} {p['dishwasher_cycles_per_week']}x/wk")
        st.write(f"Microwave: {'✅' if p['has_microwave'] else '❌'}")
        st.write(f"Electric stove: {'✅' if p['has_electric_stove'] else '❌'}")

# ── Tab 2: Consumption ────────────────────────────────────────────────────────
with tab2:
    st.subheader("Energy Consumption Breakdown  (Tasks 6-8)")
    col_chart,col_funnel = st.columns(2)

    items  = {k:v for k,v in bd.items() if k != "Total" and v > 0}
    labels = list(items.keys())
    values = list(items.values())

    with col_chart:
        fig_pie = px.pie(values=values, names=labels,
                         title="Appliance share of gross consumption",
                         hole=0.4)
        fig_pie.update_layout(margin=dict(t=40,b=0,l=0,r=0))
        st.plotly_chart(fig_pie, use_container_width=True)

    with col_funnel:
        gross = result["gross_consumption_kwh"]
        cf    = result["climate_factor"]
        inf_f = result["insulation_factor"]
        solar = result["solar_generation_kwh"]

        fig_funnel = go.Figure(go.Waterfall(
            orientation="v",
            measure=["absolute","relative","relative","relative","total"],
            x=["Gross","Climate adj.","Insulation adj.","Solar offset","Net Grid"],
            y=[gross,
               round(gross*(cf-1),3),
               round(gross*cf*(inf_f-1),3),
               -solar,
               0],
            connector={"line":{"color":"#475569"}},
            decreasing={"marker":{"color":"#22c55e"}},
            increasing={"marker":{"color":"#ef4444"}},
            totals={"marker":{"color":"#3b82f6"}},
        ))
        fig_funnel.update_layout(title="Consumption waterfall (kWh/day)",
                                 margin=dict(t=40,b=0,l=0,r=0))
        st.plotly_chart(fig_funnel, use_container_width=True)

    st.markdown("**Appliance-level breakdown**")
    df_bd = pd.DataFrame({"Appliance":labels,"kWh/day":values})
    df_bd["% share"] = (df_bd["kWh/day"]/df_bd["kWh/day"].sum()*100).round(1)
    df_bd = df_bd.sort_values("kWh/day",ascending=False).reset_index(drop=True)
    st.dataframe(df_bd, use_container_width=True, hide_index=True)

# ── Tab 3: Benchmark ──────────────────────────────────────────────────────────
with tab3:
    st.subheader("Benchmark Against Dataset  (Task 10)")

    if "error" in bm:
        st.warning(bm["error"])
    else:
        bc1,bc2,bc3,bc4 = st.columns(4)
        bc1.metric("Peer count",  bm["peer_count"])
        bc2.metric("Peer min",    f"{bm['peer_min']} kWh/day")
        bc3.metric("Peer mean",   f"{bm['peer_mean']} kWh/day")
        bc4.metric("Peer max",    f"{bm['peer_max']} kWh/day")

        all_daily = bm.get("all_daily",[])
        if all_daily:
            fig_hist = go.Figure()
            fig_hist.add_trace(go.Histogram(x=all_daily, nbinsx=20,
                name="Peer distribution", marker_color="#3b82f6", opacity=0.7))
            fig_hist.add_vline(x=net_kwh, line_width=3, line_dash="dash",
                line_color="#ef4444",
                annotation_text=f"You: {net_kwh:.1f}",
                annotation_position="top right")
            fig_hist.add_vline(x=bm["peer_mean"], line_width=2, line_dash="dot",
                line_color="#22c55e",
                annotation_text=f"Mean: {bm['peer_mean']}",
                annotation_position="top left")
            fig_hist.update_layout(
                title=f"Daily kWh distribution — {bm['peer_count']} peer households",
                xaxis_title="kWh/day", yaxis_title="Count",
                margin=dict(t=40,b=40,l=40,r=40))
            st.plotly_chart(fig_hist, use_container_width=True)

        st.markdown(f"""
| Metric | Value |
|--------|-------|
| P25 (efficient quartile) | {bm['peer_p25']} kWh/day |
| P75 (high-use quartile)  | {bm['peer_p75']} kWh/day |
| Avg peer monthly bill    | ₹{bm['peer_avg_bill']:,.0f} |
| Peers with solar         | {bm['pct_solar']}% |
| Your net grid draw       | {net_kwh:.2f} kWh/day |
| vs peer mean             | {vs_pct:+.1f}% |
        """)

# ── Tab 4: Solar ROI ─────────────────────────────────────────────────────────
with tab4:
    st.subheader("Solar ROI Analysis  (Task 11)")

    sizes  = list(roi.keys())
    savings= [roi[s]["savings_inr_yr"] for s in sizes]
    costs  = [roi[s]["cost_inr"]       for s in sizes]
    pbacks = [roi[s]["payback_yrs"]    for s in sizes]
    net25  = [roi[s]["net25"]          for s in sizes]

    sc1,sc2 = st.columns(2)
    with sc1:
        fig_bar = go.Figure()
        fig_bar.add_bar(name="Annual savings (₹)", x=sizes, y=savings, marker_color="#22c55e")
        fig_bar.add_bar(name="Capital cost (₹)",   x=sizes, y=costs,   marker_color="#ef4444")
        fig_bar.update_layout(barmode="group", title="Savings vs cost by system size",
                              margin=dict(t=40,b=0,l=0,r=0))
        st.plotly_chart(fig_bar, use_container_width=True)

    with sc2:
        fig_net = px.bar(x=sizes, y=net25, color=net25,
                         color_continuous_scale=["#ef4444","#22c55e"],
                         title="25-year net savings (₹)",
                         labels={"x":"System size","y":"Net savings (₹)"})
        fig_net.update_layout(margin=dict(t=40,b=0,l=0,r=0),
                              coloraxis_showscale=False)
        st.plotly_chart(fig_net, use_container_width=True)

    st.markdown("**Full ROI comparison table**")
    df_roi = pd.DataFrame({
        "System":           sizes,
        "Gen kWh/yr":       [roi[s]["gen_kwh_yr"]      for s in sizes],
        "Annual savings ₹": savings,
        "Capital cost ₹":   costs,
        "Payback (yrs)":    pbacks,
        "25-yr net ₹":      net25,
    })
    st.dataframe(df_roi, use_container_width=True, hide_index=True)

# ── Tab 5: Recommendations ────────────────────────────────────────────────────
with tab5:
    st.subheader("Energy-Saving Recommendations  (Task 12 · GPT-4o)")
    for line in result["recommendations"].strip().split("\n"):
        if line.strip():
            st.markdown(line)

# ── Tab 6: Audit Log ──────────────────────────────────────────────────────────
with tab6:
    st.subheader("Agent Audit Log")
    for line in result["log"]:
        parts = line.split("] ", 1)
        if len(parts) == 2:
            ts, msg = parts
            st.markdown(
                f'<span style="color:#475569;font-family:monospace;font-size:12px;">{ts}]</span> '
                f'<span style="color:#cbd5e1;font-family:monospace;font-size:12px;">{msg}</span>',
                unsafe_allow_html=True)
        else:
            st.markdown(
                f'<span style="font-family:monospace;font-size:12px;">{line}</span>',
                unsafe_allow_html=True)