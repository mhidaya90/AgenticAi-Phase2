# Household Energy Requirement Calculator & Advisor

AI-powered energy calculator for Indian households — built on a 1,000-profile dataset spanning 5 climate zones, 3 city tiers, and 4 house types.

## Features

- **Appliance-level energy breakdown** with climate & insulation adjustments
- **Benchmarking** against similar households in the dataset
- **Solar ROI analysis** for 1, 3, 5, and 10 kWp options
- **Prioritised recommendations** with quantified monthly savings

## Project Structure

```
household_energy/
├── engine.py           ← Core calculation logic (no dependencies)
├── main.py             ← FastAPI backend
├── run_tests.py        ← Test runner (no pytest needed)
├── requirements.txt
├── data/
│   └── households.csv  ← 1,000-household benchmark dataset
├── static/
│   └── index.html      ← Chat UI frontend
└── tests/
    └── test_engine.py  ← pytest-compatible test suite
```

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run tests
python3 run_tests.py

# 3. Start the server
uvicorn main:app --reload --port 8000

# 4. Open browser
# http://localhost:8000
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/analyse` | Full household energy analysis |
| GET | `/api/health` | Health check |
| GET | `/api/options` | Valid dropdown values |

### Sample Request

```bash
curl -X POST http://localhost:8000/api/analyse \
  -H "Content-Type: application/json" \
  -d '{
    "house_type": "Apartment",
    "floor_area_sqft": 1000,
    "num_bedrooms": 2,
    "num_floors": 1,
    "city_tier": "Tier 2",
    "climate_zone": "Composite",
    "num_adults": 2,
    "num_children": 1,
    "has_ac": true,
    "num_ac_units": 1,
    "ac_star_rating": 3,
    "ac_usage_hrs_per_day": 8,
    "num_ceiling_fans": 3,
    "num_led_bulbs": 10,
    "avg_lighting_hrs_per_day": 6,
    "water_heater_type": "Electric",
    "has_refrigerator": true,
    "fridge_star_rating": 3,
    "insulation_quality": "Average"
  }'
```

## Test Coverage (43 tests)

| Category | Tests |
|----------|-------|
| TC01 Output Structure | 3 |
| TC02 Energy Calculation | 17 |
| TC03 Benchmark | 4 |
| TC04 Solar ROI | 7 |
| TC05 Recommendations | 8 |
| TC06 Edge Cases | 5 |

## Calculation Logic

1. **Gross consumption** = sum of appliance wattage × usage hours
2. **Adjusted consumption** = gross × climate factor × insulation factor
3. **Net grid draw** = adjusted − solar generation (kWp × peak sun hours × 0.8 efficiency)
4. **Monthly bill** = net daily kWh × 30 × city tariff (₹/kWh)
5. **Benchmark** = percentile position vs peers with same house type, climate zone, and bedroom count
