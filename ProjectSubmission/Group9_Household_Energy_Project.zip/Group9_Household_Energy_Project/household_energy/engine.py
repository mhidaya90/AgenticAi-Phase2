"""
Household Energy Requirement Calculator & Advisor
Core calculation engine
"""
import csv
import math
import os
from dataclasses import dataclass, field
from typing import Optional

# ── Constants ────────────────────────────────────────────────────────────────

CLIMATE_FACTORS = {
    "Hot & Humid": 1.25,
    "Hot & Dry":   1.20,
    "Composite":   1.10,
    "Temperate":   1.00,
    "Cold":        0.95,
}

INSULATION_FACTORS = {
    "Excellent": 0.85,
    "Good":      0.95,
    "Average":   1.00,
    "Poor":      1.15,
}

TARIFF_BY_TIER = {
    "Tier 1": 7.5,   # ₹/kWh
    "Tier 2": 6.5,
    "Tier 3": 5.5,
}

PEAK_SUN_HOURS = {
    "Hot & Humid": 4.5,
    "Hot & Dry":   6.0,
    "Composite":   5.0,
    "Temperate":   4.0,
    "Cold":        3.5,
}

SOLAR_COST_PER_KWP = 65_000       # ₹
SOLAR_LIFETIME_YEARS = 25
CO2_PER_KWH = 0.82                # kg CO₂/kWh (Indian grid average)

AC_WATT_BY_STAR = {1: 1800, 2: 1600, 3: 1400, 4: 1200, 5: 1000}
FRIDGE_WATT_BY_STAR = {1: 200, 2: 175, 3: 150, 4: 130, 5: 110}

# ── Input dataclass ───────────────────────────────────────────────────────────

@dataclass
class HouseholdInput:
    # Profile
    house_type: str          # Apartment | Row House | Independent House | Villa
    floor_area_sqft: float
    num_bedrooms: int
    num_floors: int
    city_tier: str           # Tier 1 | Tier 2 | Tier 3
    climate_zone: str

    # Occupancy
    num_adults: int
    num_children: int

    # Appliances – AC
    has_ac: bool = False
    num_ac_units: int = 0
    ac_star_rating: int = 3
    ac_usage_hrs_per_day: float = 0.0

    # Lighting
    num_ceiling_fans: int = 0
    num_led_bulbs: int = 0
    num_cfl_bulbs: int = 0
    num_incandescent_bulbs: int = 0
    avg_lighting_hrs_per_day: float = 6.0

    # Water heater
    water_heater_type: str = "None"   # Electric | Solar+Backup | None | Gas
    water_heater_capacity_L: int = 25
    water_heater_usage_hrs_per_day: float = 1.0

    # Kitchen & laundry
    has_refrigerator: bool = True
    fridge_capacity_L: int = 250
    fridge_star_rating: int = 3
    has_microwave: bool = False
    has_electric_stove: bool = False
    has_dishwasher: bool = False
    dishwasher_cycles_per_week: int = 0
    has_washing_machine: bool = False
    washing_machine_type: str = "Front Load"   # Front Load | Top Load | Semi-Automatic
    washing_cycles_per_week: int = 5
    has_dryer: bool = False

    # Entertainment / computing
    num_tvs: int = 1
    tv_screen_size_inch: int = 40
    tv_usage_hrs_per_day: float = 4.0
    num_computers: int = 1
    computer_usage_hrs_per_day: float = 4.0

    # Building envelope
    insulation_quality: str = "Average"
    window_type: str = "Single Pane"
    roof_type: str = "Flat RCC"

    # Renewable assets
    has_solar_panels: bool = False
    solar_capacity_kWp: float = 0.0
    has_battery_storage: bool = False
    battery_capacity_kWh: float = 0.0

    @property
    def num_occupants(self):
        return self.num_adults + self.num_children


# ── Calculation engine ────────────────────────────────────────────────────────

def estimate_appliance_consumption(inp: HouseholdInput) -> dict:
    """Return dict of {appliance: daily_kWh}"""
    daily = {}

    # AC
    if inp.has_ac and inp.num_ac_units > 0:
        watt = AC_WATT_BY_STAR.get(inp.ac_star_rating, 1400)
        daily["Air Conditioners"] = inp.num_ac_units * watt * inp.ac_usage_hrs_per_day / 1000

    # Fans
    if inp.num_ceiling_fans:
        daily["Ceiling Fans"] = inp.num_ceiling_fans * 75 * 12 / 1000   # 75W, 12 hrs assumed

    # Lighting
    led_w = inp.num_led_bulbs * 9
    cfl_w = inp.num_cfl_bulbs * 15
    inc_w = inp.num_incandescent_bulbs * 60
    daily["Lighting"] = (led_w + cfl_w + inc_w) * inp.avg_lighting_hrs_per_day / 1000

    # Water heater (Electric or Solar+Backup)
    if inp.water_heater_type in ("Electric", "Solar + Backup"):
        geyser_w = 2000 if inp.water_heater_capacity_L <= 25 else 3000
        daily["Water Heater"] = geyser_w * inp.water_heater_usage_hrs_per_day / 1000

    # Refrigerator (24 hrs)
    if inp.has_refrigerator:
        fridge_w = FRIDGE_WATT_BY_STAR.get(inp.fridge_star_rating, 150)
        daily["Refrigerator"] = fridge_w * 24 / 1000

    # Microwave
    if inp.has_microwave:
        daily["Microwave"] = 1200 * 0.5 / 1000   # 1.2 kW, ~30 min/day

    # Electric stove
    if inp.has_electric_stove:
        daily["Electric Stove"] = 2000 * 1.5 / 1000

    # Dishwasher
    if inp.has_dishwasher and inp.dishwasher_cycles_per_week > 0:
        daily["Dishwasher"] = 1200 * (inp.dishwasher_cycles_per_week / 7) / 1000

    # Washing machine
    if inp.has_washing_machine and inp.washing_cycles_per_week > 0:
        wm_w = {"Front Load": 500, "Top Load": 600, "Semi-Automatic": 400}.get(inp.washing_machine_type, 500)
        daily["Washing Machine"] = wm_w * (inp.washing_cycles_per_week / 7) / 1000
    if inp.has_dryer:
        daily["Dryer"] = 3000 * (inp.washing_cycles_per_week / 7) / 1000

    # TVs
    if inp.num_tvs > 0:
        tv_w = 30 + inp.tv_screen_size_inch * 0.5
        daily["Television(s)"] = inp.num_tvs * tv_w * inp.tv_usage_hrs_per_day / 1000

    # Computers
    if inp.num_computers > 0:
        daily["Computers"] = inp.num_computers * 150 * inp.computer_usage_hrs_per_day / 1000

    return daily


def calculate_energy(inp: HouseholdInput) -> dict:
    """Full energy analysis for a household."""

    # Step 1: appliance breakdown
    appliance_kwh = estimate_appliance_consumption(inp)
    gross_daily_kwh = sum(appliance_kwh.values())

    # Step 2: adjustments
    climate_factor = CLIMATE_FACTORS.get(inp.climate_zone, 1.0)
    insulation_factor = INSULATION_FACTORS.get(inp.insulation_quality, 1.0)
    adjusted_daily_kwh = gross_daily_kwh * climate_factor * insulation_factor

    # Step 3: solar offset
    solar_gen_daily = 0.0
    if inp.has_solar_panels and inp.solar_capacity_kWp > 0:
        psh = PEAK_SUN_HOURS.get(inp.climate_zone, 4.5)
        solar_gen_daily = inp.solar_capacity_kWp * psh * 0.8   # 80% system efficiency
    net_daily_kwh = max(0, adjusted_daily_kwh - solar_gen_daily)

    # Step 4: bill
    tariff = TARIFF_BY_TIER.get(inp.city_tier, 6.5)
    monthly_kwh = net_daily_kwh * 30
    monthly_bill = monthly_kwh * tariff

    # Step 5: peak load estimate
    peak_load_kw = gross_daily_kwh / 6   # rough peak assumption

    return {
        "appliance_breakdown": appliance_kwh,
        "gross_daily_kwh": round(gross_daily_kwh, 2),
        "climate_factor": climate_factor,
        "insulation_factor": insulation_factor,
        "adjusted_daily_kwh": round(adjusted_daily_kwh, 2),
        "solar_gen_daily_kwh": round(solar_gen_daily, 2),
        "net_daily_kwh": round(net_daily_kwh, 2),
        "monthly_kwh": round(monthly_kwh, 1),
        "monthly_bill_inr": round(monthly_bill, 0),
        "peak_load_kw": round(peak_load_kw, 2),
        "tariff_per_kwh": tariff,
    }


def benchmark(inp: HouseholdInput, data_path: str = "data/households.csv") -> dict:
    """Compare against similar households in the dataset."""
    peers = []
    try:
        with open(data_path, newline="") as f:
            for row in csv.DictReader(f):
                if (row["house_type"] == inp.house_type and
                        row["climate_zone"] == inp.climate_zone and
                        row["num_bedrooms"] == str(inp.num_bedrooms)):
                    peers.append(float(row["daily_energy_consumption_kWh"]))
    except FileNotFoundError:
        return {}

    if not peers:
        return {}

    peers.sort()
    avg = sum(peers) / len(peers)
    p25 = peers[len(peers) // 4]
    p75 = peers[3 * len(peers) // 4]
    return {
        "peer_count": len(peers),
        "peer_avg_daily_kwh": round(avg, 2),
        "peer_p25_daily_kwh": round(p25, 2),
        "peer_p75_daily_kwh": round(p75, 2),
    }


def solar_roi(inp: HouseholdInput, energy_result: dict) -> list:
    """Evaluate 1, 3, 5, 10 kWp solar options."""
    tariff = energy_result["tariff_per_kwh"]
    psh = PEAK_SUN_HOURS.get(inp.climate_zone, 4.5)
    current_monthly_kwh = energy_result["monthly_kwh"]
    options = []
    for cap in [1, 3, 5, 10]:
        gen_daily = cap * psh * 0.8
        gen_monthly = gen_daily * 30
        savings_monthly = min(gen_monthly, current_monthly_kwh) * tariff
        savings_annual = savings_monthly * 12
        capital_cost = cap * SOLAR_COST_PER_KWP
        payback_years = capital_cost / savings_annual if savings_annual > 0 else 999
        net_25yr = savings_annual * SOLAR_LIFETIME_YEARS - capital_cost
        co2_annual = gen_monthly * 12 * CO2_PER_KWH
        options.append({
            "capacity_kWp": cap,
            "annual_gen_kWh": round(gen_daily * 365, 0),
            "monthly_savings_inr": round(savings_monthly, 0),
            "annual_savings_inr": round(savings_annual, 0),
            "capital_cost_inr": capital_cost,
            "payback_years": round(payback_years, 1),
            "net_25yr_savings_inr": round(net_25yr, 0),
            "co2_offset_kg_per_year": round(co2_annual, 0),
        })
    return options


def recommendations(inp: HouseholdInput, energy_result: dict) -> list:
    """Return prioritised, quantified efficiency recommendations."""
    recs = []
    tariff = energy_result["tariff_per_kwh"]

    # Incandescent → LED
    if inp.num_incandescent_bulbs > 0:
        saving_w = inp.num_incandescent_bulbs * (60 - 9)
        saving_kwh = saving_w * inp.avg_lighting_hrs_per_day * 30 / 1000
        recs.append({
            "priority": 1,
            "action": f"Replace {inp.num_incandescent_bulbs} incandescent bulbs with LEDs",
            "monthly_saving_kwh": round(saving_kwh, 1),
            "monthly_saving_inr": round(saving_kwh * tariff, 0),
            "effort": "Low",
        })

    # CFL → LED
    if inp.num_cfl_bulbs > 0:
        saving_w = inp.num_cfl_bulbs * (15 - 9)
        saving_kwh = saving_w * inp.avg_lighting_hrs_per_day * 30 / 1000
        recs.append({
            "priority": 2,
            "action": f"Replace {inp.num_cfl_bulbs} CFL bulbs with LEDs",
            "monthly_saving_kwh": round(saving_kwh, 1),
            "monthly_saving_inr": round(saving_kwh * tariff, 0),
            "effort": "Low",
        })

    # AC thermostat (set to 24°C saves ~6% per °C)
    if inp.has_ac and inp.ac_star_rating < 3:
        watt = AC_WATT_BY_STAR.get(inp.ac_star_rating, 1800)
        saving_kwh = inp.num_ac_units * watt * inp.ac_usage_hrs_per_day * 30 * 0.12 / 1000
        recs.append({
            "priority": 3,
            "action": "Upgrade ACs to 3-star or higher rating",
            "monthly_saving_kwh": round(saving_kwh, 1),
            "monthly_saving_inr": round(saving_kwh * tariff, 0),
            "effort": "High",
        })

    if inp.has_ac and inp.ac_usage_hrs_per_day > 8:
        saving_kwh = inp.num_ac_units * AC_WATT_BY_STAR.get(inp.ac_star_rating, 1400) * 2 * 30 / 1000
        recs.append({
            "priority": 3,
            "action": "Set AC thermostat to 24°C and reduce usage by 2 hrs/day",
            "monthly_saving_kwh": round(saving_kwh, 1),
            "monthly_saving_inr": round(saving_kwh * tariff, 0),
            "effort": "Low",
        })

    # Electric → Solar water heater
    if inp.water_heater_type == "Electric":
        saving_kwh = 2000 * inp.water_heater_usage_hrs_per_day * 30 * 0.80 / 1000
        recs.append({
            "priority": 4,
            "action": "Switch to solar water heater (80% reduction in heating energy)",
            "monthly_saving_kwh": round(saving_kwh, 1),
            "monthly_saving_inr": round(saving_kwh * tariff, 0),
            "effort": "Medium",
        })

    # Poor insulation
    if inp.insulation_quality in ("Poor", "Average"):
        saving_frac = 0.12 if inp.insulation_quality == "Poor" else 0.06
        saving_kwh = energy_result["adjusted_daily_kwh"] * 30 * saving_frac
        recs.append({
            "priority": 5,
            "action": "Improve insulation / install double-pane windows",
            "monthly_saving_kwh": round(saving_kwh, 1),
            "monthly_saving_inr": round(saving_kwh * tariff, 0),
            "effort": "High",
        })

    # Rooftop solar (if not installed)
    if not inp.has_solar_panels:
        psh = PEAK_SUN_HOURS.get(inp.climate_zone, 4.5)
        cap = 3
        saving_kwh = cap * psh * 0.8 * 30
        recs.append({
            "priority": 6,
            "action": f"Install {cap} kWp rooftop solar (see Solar ROI analysis)",
            "monthly_saving_kwh": round(min(saving_kwh, energy_result["monthly_kwh"]), 1),
            "monthly_saving_inr": round(min(saving_kwh, energy_result["monthly_kwh"]) * tariff, 0),
            "effort": "High",
        })

    recs.sort(key=lambda r: (-r["monthly_saving_inr"], r["priority"]))
    for i, r in enumerate(recs, 1):
        r["priority"] = i
    return recs


def full_analysis(inp: HouseholdInput, data_path: str = "data/households.csv") -> dict:
    energy = calculate_energy(inp)
    bench = benchmark(inp, data_path)
    solar = solar_roi(inp, energy)
    recs = recommendations(inp, energy)
    return {
        "energy": energy,
        "benchmark": bench,
        "solar_roi": solar,
        "recommendations": recs,
    }
