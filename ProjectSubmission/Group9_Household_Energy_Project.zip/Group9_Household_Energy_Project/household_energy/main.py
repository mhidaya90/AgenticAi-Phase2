"""
Household Energy Requirement Calculator & Advisor
FastAPI backend
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from typing import Optional
import os

from engine import HouseholdInput, full_analysis

app = FastAPI(title="Home Energy Assistant", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "households.csv")


class HouseholdRequest(BaseModel):
    # Profile
    house_type: str = Field("Apartment", description="Apartment | Row House | Independent House | Villa")
    floor_area_sqft: float = Field(1000, gt=0)
    num_bedrooms: int = Field(2, ge=1, le=10)
    num_floors: int = Field(1, ge=1)
    city_tier: str = Field("Tier 2", description="Tier 1 | Tier 2 | Tier 3")
    climate_zone: str = Field("Composite")

    num_adults: int = Field(2, ge=1)
    num_children: int = Field(0, ge=0)

    has_ac: bool = False
    num_ac_units: int = 0
    ac_star_rating: int = Field(3, ge=1, le=5)
    ac_usage_hrs_per_day: float = Field(0.0, ge=0, le=24)

    num_ceiling_fans: int = Field(0, ge=0)
    num_led_bulbs: int = Field(0, ge=0)
    num_cfl_bulbs: int = Field(0, ge=0)
    num_incandescent_bulbs: int = Field(0, ge=0)
    avg_lighting_hrs_per_day: float = Field(6.0, ge=0, le=24)

    water_heater_type: str = "Electric"
    water_heater_capacity_L: int = 25
    water_heater_usage_hrs_per_day: float = Field(1.0, ge=0, le=24)

    has_refrigerator: bool = True
    fridge_capacity_L: int = 250
    fridge_star_rating: int = Field(3, ge=1, le=5)
    has_microwave: bool = False
    has_electric_stove: bool = False
    has_dishwasher: bool = False
    dishwasher_cycles_per_week: int = Field(0, ge=0)
    has_washing_machine: bool = False
    washing_machine_type: str = "Front Load"
    washing_cycles_per_week: int = Field(5, ge=0)
    has_dryer: bool = False

    num_tvs: int = Field(1, ge=0)
    tv_screen_size_inch: int = Field(40, ge=0)
    tv_usage_hrs_per_day: float = Field(4.0, ge=0, le=24)
    num_computers: int = Field(1, ge=0)
    computer_usage_hrs_per_day: float = Field(4.0, ge=0, le=24)

    insulation_quality: str = "Average"
    window_type: str = "Single Pane"
    roof_type: str = "Flat RCC"

    has_solar_panels: bool = False
    solar_capacity_kWp: float = Field(0.0, ge=0)
    has_battery_storage: bool = False
    battery_capacity_kWh: float = Field(0.0, ge=0)


@app.post("/api/analyse")
def analyse(req: HouseholdRequest):
    try:
        inp = HouseholdInput(**req.dict())
        result = full_analysis(inp, DATA_PATH)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/health")
def health():
    return {"status": "ok", "version": "1.0.0"}


@app.get("/api/options")
def options():
    """Return valid dropdown values for the frontend."""
    return {
        "house_types": ["Apartment", "Row House", "Independent House", "Villa"],
        "city_tiers": ["Tier 1", "Tier 2", "Tier 3"],
        "climate_zones": ["Hot & Humid", "Hot & Dry", "Composite", "Temperate", "Cold"],
        "insulation_quality": ["Excellent", "Good", "Average", "Poor"],
        "water_heater_types": ["Electric", "Solar + Backup", "Gas", "None"],
        "washing_machine_types": ["Front Load", "Top Load", "Semi-Automatic"],
        "window_types": ["Single Pane", "Double Pane", "Triple Pane"],
        "roof_types": ["Flat RCC", "Sloped Tiled", "Green Roof"],
    }


# Serve frontend static files (must be last)
app.mount("/", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static"), html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    import webbrowser
    import threading

    threading.Timer(1.5, lambda: webbrowser.open("http://127.0.0.1:8000")).start()
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)