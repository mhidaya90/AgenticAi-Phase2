"""
Household Energy Requirement Calculator & Advisor

Agents:
  1. ProfileAgent        — parses household description into structured data
  2. ConsumptionAgent    — estimates gross energy consumption (physics-based)
  3. BenchmarkAgent      — compares against dataset peers
  4. SolarROIAgent       — evaluates 1/3/5/10 kWp solar scenarios
  5. RecommendationAgent — produces prioritised efficiency recommendations
  6. ReportAgent         — assembles and presents the final report

Setup:
    pip install -r requirements.txt
    python energy-saver-agent.py
"""

import os
import json
import pandas as pd
from typing import TypedDict, Optional, Any
from dotenv import load_dotenv

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END

# ── OpenAI API Key ────────────────────────────────────────────────────────────
load_dotenv()

print(f"OPENAI_API_KEY is set: {'OPENAI_API_KEY' in os.environ}")

# ── Dataset path (keep next to this script) ───────────────────────────────────
DATASET_PATH = "household_energy_requirement.csv"

# ── LLM ───────────────────────────────────────────────────────────────────────
llm = ChatOpenAI(model="gpt-4o", temperature=0)


# ─────────────────────────────────────────────────────────────────────────────
# Shared State
# ─────────────────────────────────────────────────────────────────────────────
class EnergyState(TypedDict):
    user_input:      str
    profile:         Optional[dict]
    consumption:     Optional[dict]
    benchmark:       Optional[dict]
    solar_roi:       Optional[list]
    recommendations: Optional[list]
    report:          Optional[str]
    errors:          list


# ─────────────────────────────────────────────────────────────────────────────
# Helper: call LLM and parse JSON response
# ─────────────────────────────────────────────────────────────────────────────
def llm_json(system_prompt: str, user_content: str) -> Any:
    response = llm.invoke([
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_content),
    ])
    text = response.content.strip()
    if text.startswith("```"):
        text = "\n".join(text.split("\n")[1:])
        text = text.rsplit("```", 1)[0].strip()
    return json.loads(text)


# ─────────────────────────────────────────────────────────────────────────────
# Agent 1 — ProfileAgent
# ─────────────────────────────────────────────────────────────────────────────
def profile_agent(state: EnergyState) -> EnergyState:
    """Parse free-text user input into a structured household profile."""

    system = """You are a data-extraction assistant for an energy advisor app.
Extract a household profile from the user's description and return ONLY valid JSON
(no markdown, no commentary) with EXACTLY these keys and value types:

{
  "house_type": str,           // Apartment | Row House | Independent House | Villa | Bungalow
  "num_bedrooms": int,
  "floor_area_sqft": float,
  "num_floors": int,
  "num_adults": int,
  "num_children": int,
  "climate_zone": str,         // Hot & Humid | Hot & Dry | Composite | Temperate | Cold
  "city_tier": str,            // Tier 1 | Tier 2 | Tier 3
  "insulation_quality": str,   // Poor | Average | Good | Excellent
  "window_type": str,          // Single Pane | Double Pane | Triple Pane
  "roof_type": str,            // Flat RCC | Sloped Tiled | Green Roof | Metal Sheet
  "has_ac": bool,
  "num_ac_units": int,
  "ac_star_rating": int,       // 1-5
  "ac_usage_hrs_per_day": float,
  "num_ceiling_fans": int,
  "num_led_bulbs": int,
  "num_cfl_bulbs": int,
  "num_incandescent_bulbs": int,
  "avg_lighting_hrs_per_day": float,
  "water_heater_type": str,    // Electric | Gas | Solar | Solar + Backup | Heat Pump | None
  "water_heater_capacity_L": int,
  "water_heater_usage_hrs_per_day": float,
  "has_refrigerator": bool,
  "fridge_capacity_L": int,
  "fridge_star_rating": int,
  "has_microwave": bool,
  "has_electric_stove": bool,
  "has_dishwasher": bool,
  "dishwasher_cycles_per_week": int,
  "has_washing_machine": bool,
  "washing_machine_type": str, // Front Load | Top Load | Semi-Automatic
  "washing_cycles_per_week": int,
  "has_dryer": bool,
  "num_tvs": int,
  "tv_screen_size_inch": int,
  "tv_usage_hrs_per_day": float,
  "num_computers": int,
  "computer_usage_hrs_per_day": float,
  "has_solar_panels": bool,
  "solar_capacity_kWp": float,
  "has_battery_storage": bool,
  "battery_capacity_kWh": float,
  "electricity_tariff_per_kwh": float
}

Fill missing numeric fields with sensible India-specific defaults.
Booleans default to false; strings default to the most common/neutral option."""

    try:
        profile = llm_json(system, state["user_input"])
        bool_keys = ("has_ac", "has_refrigerator", "has_microwave", "has_electric_stove",
                     "has_dishwasher", "has_washing_machine", "has_dryer",
                     "has_solar_panels", "has_battery_storage")
        for k in bool_keys:
            if k in profile:
                profile[k] = bool(profile[k])
        return {**state, "profile": profile}
    except Exception as exc:
        return {**state, "errors": state["errors"] + [f"ProfileAgent: {exc}"]}


# ─────────────────────────────────────────────────────────────────────────────
# Agent 2 — ConsumptionAgent
# ─────────────────────────────────────────────────────────────────────────────

CLIMATE_FACTORS = {
    "Hot & Humid": 1.20,
    "Hot & Dry":   1.15,
    "Composite":   1.10,
    "Temperate":   1.00,
    "Cold":        1.05,
}

INSULATION_FACTORS = {
    "Poor":      1.15,
    "Average":   1.05,
    "Good":      1.00,
    "Excellent": 0.90,
}

TARIFF_BY_TIER = {"Tier 1": 6.5, "Tier 2": 5.5, "Tier 3": 4.5}

PEAK_SUN_HOURS = {
    "Hot & Humid": 4.5,
    "Hot & Dry":   5.5,
    "Composite":   5.0,
    "Temperate":   4.0,
    "Cold":        3.5,
}


def consumption_agent(state: EnergyState) -> EnergyState:
    """Physics-based appliance energy calculation with climate/insulation adjustments."""

    if not state.get("profile"):
        return {**state, "errors": state["errors"] + ["ConsumptionAgent: no profile available"]}

    p = state["profile"]
    breakdown = {}

    # AC
    ac_watts = {1: 2000, 2: 1800, 3: 1600, 4: 1400, 5: 1200}
    if p.get("has_ac") and p.get("num_ac_units", 0) > 0:
        watt = ac_watts.get(p.get("ac_star_rating", 3), 1600)
        breakdown["ac"] = p["num_ac_units"] * watt * p.get("ac_usage_hrs_per_day", 6) / 1000

    # Ceiling fans (75 W each)
    if p.get("num_ceiling_fans", 0):
        breakdown["fans"] = p["num_ceiling_fans"] * 75 * p.get("avg_lighting_hrs_per_day", 8) / 1000

    # Lighting
    led    = p.get("num_led_bulbs", 0) * 10
    cfl    = p.get("num_cfl_bulbs", 0) * 20
    incand = p.get("num_incandescent_bulbs", 0) * 60
    hrs    = p.get("avg_lighting_hrs_per_day", 8)
    breakdown["lighting"] = (led + cfl + incand) * hrs / 1000

    # Water heater
    wh_type = p.get("water_heater_type", "None")
    if wh_type not in ("None", "Solar"):
        wh_watt = 2000 if "Electric" in wh_type else 1500
        breakdown["water_heater"] = wh_watt * p.get("water_heater_usage_hrs_per_day", 1.5) / 1000

    # Refrigerator
    if p.get("has_refrigerator"):
        fridge_watt = max(50, 250 - p.get("fridge_star_rating", 3) * 25)
        breakdown["refrigerator"] = fridge_watt * 24 / 1000

    # Washing machine
    if p.get("has_washing_machine"):
        kwh_cycle = 0.5 if str(p.get("washing_machine_type", "")).startswith("Front") else 0.9
        breakdown["washing_machine"] = kwh_cycle * p.get("washing_cycles_per_week", 5) / 7

    # Dryer
    if p.get("has_dryer"):
        breakdown["dryer"] = 2.5 * p.get("washing_cycles_per_week", 5) / 7

    # Microwave
    if p.get("has_microwave"):
        breakdown["microwave"] = 0.5

    # Electric stove
    if p.get("has_electric_stove"):
        breakdown["electric_stove"] = 3.0

    # Dishwasher
    if p.get("has_dishwasher") and p.get("dishwasher_cycles_per_week", 0) > 0:
        breakdown["dishwasher"] = 1.5 * p["dishwasher_cycles_per_week"] / 7

    # TVs
    if p.get("num_tvs", 0):
        breakdown["tv"] = p["num_tvs"] * 100 * p.get("tv_usage_hrs_per_day", 4) / 1000

    # Computers
    if p.get("num_computers", 0):
        breakdown["computers"] = p["num_computers"] * 150 * p.get("computer_usage_hrs_per_day", 6) / 1000

    gross_daily  = sum(breakdown.values())
    climate_f    = CLIMATE_FACTORS.get(p.get("climate_zone", "Composite"), 1.10)
    insulation_f = INSULATION_FACTORS.get(p.get("insulation_quality", "Average"), 1.05)
    adjusted_daily = gross_daily * climate_f * insulation_f

    solar_gen = 0.0
    if p.get("has_solar_panels") and p.get("solar_capacity_kWp", 0) > 0:
        sun_hrs   = PEAK_SUN_HOURS.get(p.get("climate_zone", "Composite"), 4.5)
        solar_gen = p["solar_capacity_kWp"] * sun_hrs * 0.80

    net_daily = max(0.0, adjusted_daily - solar_gen)
    tariff    = p.get("electricity_tariff_per_kwh") or TARIFF_BY_TIER.get(p.get("city_tier", "Tier 2"), 5.5)

    consumption = {
        "breakdown_kwh_per_day": {k: round(v, 3) for k, v in breakdown.items()},
        "gross_daily_kwh":       round(gross_daily, 2),
        "climate_factor":        climate_f,
        "insulation_factor":     insulation_f,
        "adjusted_daily_kwh":    round(adjusted_daily, 2),
        "solar_gen_daily_kwh":   round(solar_gen, 2),
        "net_daily_kwh":         round(net_daily, 2),
        "monthly_kwh":           round(net_daily * 30, 2),
        "tariff_per_kwh":        tariff,
        "monthly_bill_inr":      round(net_daily * 30 * tariff, 2),
    }
    return {**state, "consumption": consumption}


# ─────────────────────────────────────────────────────────────────────────────
# Agent 3 — BenchmarkAgent
# ─────────────────────────────────────────────────────────────────────────────
def benchmark_agent(state: EnergyState) -> EnergyState:
    """Compare this household against similar peers in the dataset."""

    if not state.get("profile") or not state.get("consumption"):
        return {**state, "errors": state["errors"] + ["BenchmarkAgent: missing dependencies"]}

    p = state["profile"]
    c = state["consumption"]

    try:
        df = pd.read_csv(DATASET_PATH)
    except FileNotFoundError:
        return {**state, "errors": state["errors"] + [f"BenchmarkAgent: dataset not found at {DATASET_PATH}"]}

    peers = df[
        (df["house_type"]   == p.get("house_type")) &
        (df["climate_zone"] == p.get("climate_zone")) &
        (df["num_bedrooms"].between(
            max(1, p.get("num_bedrooms", 3) - 1),
            p.get("num_bedrooms", 3) + 1
        ))
    ]
    if len(peers) < 5:
        peers = df[df["climate_zone"] == p.get("climate_zone")]

    peer_monthly = peers["monthly_energy_consumption_kWh"]
    my_monthly   = c["monthly_kwh"]
    percentile   = (peer_monthly < my_monthly).mean() * 100

    benchmark = {
        "peer_count":       int(len(peers)),
        "peer_mean_kwh":    round(float(peer_monthly.mean()), 2),
        "peer_median_kwh":  round(float(peer_monthly.median()), 2),
        "peer_p25_kwh":     round(float(peer_monthly.quantile(0.25)), 2),
        "peer_p75_kwh":     round(float(peer_monthly.quantile(0.75)), 2),
        "peer_min_kwh":     round(float(peer_monthly.min()), 2),
        "peer_max_kwh":     round(float(peer_monthly.max()), 2),
        "your_monthly_kwh": my_monthly,
        "percentile_rank":  round(percentile, 1),
        "assessment": (
            "High consumer — top quartile among peers" if percentile > 75 else
            "Moderate consumer — within typical range"  if percentile > 25 else
            "Efficient — below most similar households"
        ),
    }
    return {**state, "benchmark": benchmark}


# ─────────────────────────────────────────────────────────────────────────────
# Agent 4 — SolarROIAgent
# ─────────────────────────────────────────────────────────────────────────────

SOLAR_COST_PER_KWP   = {1: 65_000, 3: 58_000, 5: 54_000, 10: 50_000}
PANEL_LIFETIME_YEARS = 25
ANNUAL_DEGRADATION   = 0.005
SUBSIDY_FRACTION     = 0.30


def solar_roi_agent(state: EnergyState) -> EnergyState:
    """Evaluate 1, 3, 5, and 10 kWp solar installation scenarios."""

    if not state.get("profile") or not state.get("consumption"):
        return {**state, "errors": state["errors"] + ["SolarROIAgent: missing dependencies"]}

    p      = state["profile"]
    c      = state["consumption"]
    zone   = p.get("climate_zone", "Composite")
    sun    = PEAK_SUN_HOURS.get(zone, 4.5)
    tariff = c["tariff_per_kwh"]
    gross  = c["adjusted_daily_kwh"]

    scenarios = []
    for cap in [1, 3, 5, 10]:
        gen_y1   = cap * sun * 0.80 * 365
        capital  = SOLAR_COST_PER_KWP[cap] * cap
        subsidy  = capital * (SUBSIDY_FRACTION if cap <= 3 else 0.20)
        net_cost = capital - subsidy

        total_gen = sum(
            gen_y1 * ((1 - ANNUAL_DEGRADATION) ** yr)
            for yr in range(PANEL_LIFETIME_YEARS)
        )
        ann_sav = min(gen_y1, gross * 365) * tariff
        payback = net_cost / ann_sav if ann_sav > 0 else 999
        co2_kg  = total_gen * 0.82

        scenarios.append({
            "capacity_kWp":           cap,
            "capital_cost_inr":       round(capital),
            "subsidy_inr":            round(subsidy),
            "net_cost_inr":           round(net_cost),
            "annual_generation_kwh":  round(gen_y1, 1),
            "annual_savings_inr":     round(ann_sav, 2),
            "simple_payback_years":   round(payback, 1),
            "lifetime_savings_inr":   round(total_gen * tariff - net_cost, 2),
            "co2_offset_25yr_tonnes": round(co2_kg / 1000, 2),
        })

    return {**state, "solar_roi": scenarios}


# ─────────────────────────────────────────────────────────────────────────────
# Agent 5 — RecommendationAgent
# ─────────────────────────────────────────────────────────────────────────────
def recommendation_agent(state: EnergyState) -> EnergyState:
    """LLM-powered prioritised efficiency recommendations."""

    if not all(state.get(k) for k in ("profile", "consumption", "benchmark")):
        return {**state, "errors": state["errors"] + ["RecommendationAgent: missing dependencies"]}

    system = """You are an expert household energy efficiency advisor for Indian households.
Given the profile, consumption breakdown, and benchmark results below,
return ONLY a JSON array (no markdown, no comment) of up to 8 improvement actions.

Each action object must have:
{
  "rank": int,
  "action": str,
  "detail": str,
  "estimated_saving_pct": float,
  "one_time_cost_inr": int,
  "payback_months": int
}

Order by highest saving first. Be specific and quantitative."""

    payload = json.dumps({
        "profile":     state["profile"],
        "consumption": state["consumption"],
        "benchmark":   state["benchmark"],
    }, default=str)

    try:
        recs = llm_json(system, payload)
        return {**state, "recommendations": recs}
    except Exception as exc:
        return {**state, "errors": state["errors"] + [f"RecommendationAgent: {exc}"]}


# ─────────────────────────────────────────────────────────────────────────────
# Agent 6 — ReportAgent
# ─────────────────────────────────────────────────────────────────────────────
def report_agent(state: EnergyState) -> EnergyState:
    """Assemble a formatted text report from all agent outputs."""

    p    = state.get("profile") or {}
    c    = state.get("consumption") or {}
    bm   = state.get("benchmark") or {}
    sr   = state.get("solar_roi") or []
    recs = state.get("recommendations") or []
    errs = state.get("errors") or []
    sep  = "─" * 70

    monthly_bill = c.get("monthly_bill_inr")
    if isinstance(monthly_bill, (int, float)):
        monthly_bill_text = f"₹{monthly_bill:,.0f}"
    else:
        monthly_bill_text = "—"

    lines = [
        "╔══════════════════════════════════════════════════════════════════════╗",
        "║       HOUSEHOLD ENERGY REQUIREMENT CALCULATOR & ADVISOR             ║",
        "╚══════════════════════════════════════════════════════════════════════╝",
        "",
        f"{'HOUSEHOLD PROFILE':^70}",
        sep,
        f"  Type          : {p.get('house_type','—')}",
        f"  Location      : {p.get('city_tier','—')} | {p.get('climate_zone','—')}",
        f"  Size          : {p.get('floor_area_sqft','—')} sqft  |  {p.get('num_bedrooms','—')} BHK  |  {p.get('num_floors','—')} floor(s)",
        f"  Occupants     : {p.get('num_adults',0)} adults + {p.get('num_children',0)} children",
        f"  Insulation    : {p.get('insulation_quality','—')}  |  Windows : {p.get('window_type','—')}",
        f"  Roof          : {p.get('roof_type','—')}",
        "",
        f"{'ENERGY CONSUMPTION':^70}",
        sep,
        "  Appliance Breakdown (kWh/day):",
    ]

    for appliance, kwh in c.get("breakdown_kwh_per_day", {}).items():
        lines.append(f"    {appliance:<22} {kwh:>6.3f} kWh")

    lines += [
        "",
        f"  Gross Daily         : {c.get('gross_daily_kwh','—'):>7} kWh",
        f"  Climate Factor      : {c.get('climate_factor','—')} ({p.get('climate_zone','—')})",
        f"  Insulation Factor   : {c.get('insulation_factor','—')} ({p.get('insulation_quality','—')})",
        f"  Adjusted Daily      : {c.get('adjusted_daily_kwh','—'):>7} kWh",
        f"  Solar Generation    : {c.get('solar_gen_daily_kwh','—'):>7} kWh/day",
        f"  Net Grid Draw       : {c.get('net_daily_kwh','—'):>7} kWh/day",
        f"  Monthly Consumption : {c.get('monthly_kwh','—'):>7} kWh",
        f"  Tariff              : ₹{c.get('tariff_per_kwh','—')}/kWh",
        f"  ★ Estimated Monthly Bill : {monthly_bill_text}",
        "",
        f"{'BENCHMARK ANALYSIS':^70}",
        sep,
        f"  Compared against {bm.get('peer_count','—')} similar households  ({p.get('house_type','—')}, {p.get('climate_zone','—')})",
        f"  Your Usage      : {bm.get('your_monthly_kwh','—')} kWh/month",
        f"  Peer Median     : {bm.get('peer_median_kwh','—')} kWh/month",
        f"  Peer Range      : {bm.get('peer_p25_kwh','—')} – {bm.get('peer_p75_kwh','—')} kWh/month (25th–75th pct)",
        f"  Percentile Rank : {bm.get('percentile_rank','—')}th percentile",
        f"  Assessment      : {bm.get('assessment','—')}",
        "",
        f"{'SOLAR ROI ANALYSIS':^70}",
        sep,
        f"  {'Cap':>5}  {'Capital':>10}  {'Subsidy':>10}  {'Net Cost':>10}  {'AnnSav':>9}  {'Payback':>8}  {'LifeSav':>12}  {'CO₂ t':>7}",
        f"  {'kWp':>5}  {'₹':>10}  {'₹':>10}  {'₹':>10}  {'₹/yr':>9}  {'Years':>8}  {'₹':>12}  {'25yr':>7}",
        "  " + "─" * 68,
    ]

    for s in sr:
        lines.append(
            f"  {s['capacity_kWp']:>5}  "
            f"{s['capital_cost_inr']:>10,}  "
            f"{s['subsidy_inr']:>10,}  "
            f"{s['net_cost_inr']:>10,}  "
            f"{s['annual_savings_inr']:>9,.0f}  "
            f"{s['simple_payback_years']:>8.1f}  "
            f"{s['lifetime_savings_inr']:>12,.0f}  "
            f"{s['co2_offset_25yr_tonnes']:>7.1f}"
        )

    lines += [
        "",
        f"{'EFFICIENCY RECOMMENDATIONS':^70}",
        sep,
    ]

    for r in recs:
        cost_info = ""
        if r.get("one_time_cost_inr", 0) > 0:
            cost_info = f"  |  Cost: ₹{r['one_time_cost_inr']:,}  |  Payback: {r.get('payback_months',0)} months"
        lines += [
            f"  #{r.get('rank','')}  {r.get('action','').upper()}",
            f"     {r.get('detail','')}",
            f"     Saving : ~{r.get('estimated_saving_pct',0):.1f}% of bill{cost_info}",
            "",
        ]

    if errs:
        lines += [sep, "  WARNINGS:", *[f"  ⚠  {e}" for e in errs], ""]

    return {**state, "report": "\n".join(lines)}


# ─────────────────────────────────────────────────────────────────────────────
# Build the LangGraph
# ─────────────────────────────────────────────────────────────────────────────
def build_graph():
    graph = StateGraph(EnergyState)

    graph.add_node("profile",        profile_agent)
    graph.add_node("consumption",    consumption_agent)
    graph.add_node("benchmark",      benchmark_agent)
    graph.add_node("solar_roi",      solar_roi_agent)
    graph.add_node("recommendation", recommendation_agent)
    graph.add_node("report",         report_agent)

    graph.set_entry_point("profile")
    graph.add_edge("profile",        "consumption")
    graph.add_edge("consumption",    "benchmark")
    graph.add_edge("benchmark",      "solar_roi")
    graph.add_edge("solar_roi",      "recommendation")
    graph.add_edge("recommendation", "report")
    graph.add_edge("report",         END)

    return graph.compile()


# ─────────────────────────────────────────────────────────────────────────────
# Sample input (used when you just press Enter)
# ─────────────────────────────────────────────────────────────────────────────
SAMPLE_INPUT = """
I live in a 3-bedroom independent house in Bengaluru (Tier 1, Composite zone).
The house is about 1500 sqft, 2 floors. We are 2 adults and 1 child.
Insulation is average, double-pane windows, flat RCC roof.

Appliances:
- 2 ACs (3-star), used 7 hours/day
- 4 ceiling fans, 8 hours/day
- 10 LED bulbs, 4 CFL bulbs, lighting ~8 hrs/day
- Electric water heater 25L, 1.5 hrs/day
- Refrigerator 300L, 4-star
- Microwave, washing machine (front-load, 5 cycles/week)
- 1 TV (55 inch, 4 hrs/day), 2 laptops (5 hrs/day each)
- No solar panels currently.

Electricity tariff is Rs 7/kWh.
"""


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────
def main():
    app = build_graph()

# 4. Generate the PNG
    png_data = app.get_graph().draw_mermaid_png()
    with open("energy_graph.png", "wb") as f:
        f.write(png_data)

    print("\n  Household Energy Requirement Calculator & Advisor  (OpenAI / GPT-4o)")
    print("=" * 70)

    if os.getenv("ENERGY_INPUT"):
        user_text = os.environ["ENERGY_INPUT"]
        print("  Using ENERGY_INPUT from environment.\n")
    else:
        print("\nDescribe your household (press Enter twice when done,")
        print("or just press Enter once to use the built-in sample):\n")
        lines, blank = [], 0
        while blank < 1:
            line = input()
            if line == "":
                blank += 1
            else:
                blank = 0
                lines.append(line)
        user_text = "\n".join(lines) if lines else SAMPLE_INPUT

    print("\n  Running multi-agent pipeline...\n")

    initial_state: EnergyState = {
        "user_input":      user_text,
        "profile":         None,
        "consumption":     None,
        "benchmark":       None,
        "solar_roi":       None,
        "recommendations": None,
        "report":          None,
        "errors":          [],
    }

    agent_labels = {
        "profile":        "ProfileAgent        — parsing household inputs",
        "consumption":    "ConsumptionAgent     — calculating energy usage",
        "benchmark":      "BenchmarkAgent       — comparing with dataset peers",
        "solar_roi":      "SolarROIAgent        — evaluating solar scenarios",
        "recommendation": "RecommendationAgent  — generating recommendations",
        "report":         "ReportAgent          — assembling final report",
    }

    final_state = None
    for event in app.stream(initial_state):
        for node_name in event:
            print(f"  OK  {agent_labels.get(node_name, node_name)}")
            final_state = event[node_name]

    print("\n" + "=" * 70)
    print(final_state["report"])

    out_path = "energy_report.json"
    with open(out_path, "w") as f:
        json.dump(
            {k: v for k, v in final_state.items() if k != "user_input"},
            f, indent=2, default=str
        )
    print(f"\n  Full JSON results saved to: {out_path}")


if __name__ == "__main__":
    main()