streamlit run main.py
