import os
import pandas as pd
from langchain.agents import create_agent
from langchain.tools import tool
from langchain_openai import ChatOpenAI

curr_dir = os.getcwd()
# print(curr_dir)
DATA_PATH = curr_dir + "\\household_energy_requirement.csv"

_df = pd.read_csv(DATA_PATH)

def loadHousehold(row_index: int) -> dict:
    """Read one household row from CSV """
    ret = {"status": "", "message": "", "record": ""}

    try:
        if row_index < 0 or row_index >= len(_df):
            ret["status"] = "EXCEPTION"
            ret["message"] = f"row_index must be between 0 and {len(_df) - 1}"
            return ret

        row = _df.iloc[row_index]
        ret["status"] = "SUCCESS"
        ret["message"] = "1 Record(s) Retrieved"
        ret["record"] = row.to_dict()
    except Exception as e:
        ret["status"] = "EXCEPTION"
        ret["message"] = str(e)

    return ret


@tool
def find_row_indexes(search_key: str, search_value: str) -> dict:
    """Find all CSV row_index values (0-based) where search_key equals search_value.
    search_key must be a valid column name (e.g. house_type, climate_zone, city_tier, num_bedrooms).
    """

    search_key = search_key.strip()
    search_value = search_value.strip()

    if search_key not in _df.columns:
        return {
            "status": "EXCEPTION",
            "message": (
                f"Invalid search_key '{search_key}'. "
                f"Valid columns: {_df.columns.tolist()}"
            ),
            "search_key": search_key,
            "search_value": search_value,
            "row_indexes": [],
            "count": 0,
        }

    column = _df[search_key]

    if pd.api.types.is_numeric_dtype(column):
        try:
            target = float(search_value) if "." in search_value else int(search_value)
            if pd.api.types.is_integer_dtype(column):
                target = int(target)
            matches = _df[column == target]
        except ValueError:
            return {
                "status": "EXCEPTION",
                "message": f"search_value '{search_value}' is not valid for numeric column '{search_key}'",
                "search_key": search_key,
                "search_value": search_value,
                "row_indexes": [],
                "count": 0,
            }
    else:
        matches = _df[column.astype(str).str.lower() == search_value.lower()]

    if matches.empty:
        sample_values = sorted(column.dropna().astype(str).unique().tolist())[:15]
        return {
            "status": "EXCEPTION",
            "message": (
                f"No rows found where {search_key} = '{search_value}'. "
                f"Sample values for {search_key}: {sample_values}"
            ),
            "search_key": search_key,
            "search_value": search_value,
            "row_indexes": [],
            "count": 0,
        }

    row_indexes = matches.index.tolist()
    return {
        "status": "SUCCESS",
        "message": f"{len(row_indexes)} Record(s) Found",
        "search_key": search_key,
        "search_value": search_value,
        "row_indexes": row_indexes,
        "count": len(row_indexes),
    }


@tool
def get_household_profile(row_index: int) -> dict:
    """Task 1 — Collect household profile: house type, floor area, bedrooms, floors, city tier, climate zone."""

    response = loadHousehold(row_index)
    if response["status"] != "SUCCESS":
        return {"household_profile": response}

    row = response["record"]
    fields = [
        "house_type", "floor_area_sqft", "num_bedrooms", "num_floors",
        "city_tier", "climate_zone",
    ]
    data = {f: row[f] for f in fields}
    response["record"] = data
    return {"household_profile": response}


@tool
def get_occupancy_details(row_index: int) -> dict:
    """Task 2 — Capture occupancy: number of occupants, adults, and children."""

    response = loadHousehold(row_index)
    if response["status"] != "SUCCESS":
        return {"occupancy_details": response}

    row = response["record"]
    fields = ["num_occupants", "num_adults", "num_children"]
    data = {f: row[f] for f in fields}
    response["record"] = data
    return {"occupancy_details": response}


@tool
def get_appliance_inventory(row_index: int) -> dict:
    """Task 3 — Inventory appliances: AC, fans, lighting, water heater, fridge, washer, TV, computer, etc."""

    response = loadHousehold(row_index)
    if response["status"] != "SUCCESS":
        return {"appliance_inventory": response}

    row = response["record"]
    fields = [
        "has_ac", "num_ac_units", "ac_star_rating", "ac_usage_hrs_per_day",
        "num_ceiling_fans", "num_led_bulbs", "num_cfl_bulbs", "num_incandescent_bulbs",
        "avg_lighting_hrs_per_day", "water_heater_type", "water_heater_capacity_L",
        "water_heater_usage_hrs_per_day", "has_refrigerator", "fridge_capacity_L",
        "fridge_star_rating", "has_microwave", "has_electric_stove", "has_dishwasher",
        "dishwasher_cycles_per_week", "has_washing_machine", "washing_machine_type",
        "washing_cycles_per_week", "has_dryer", "num_tvs", "tv_screen_size_inch",
        "tv_usage_hrs_per_day", "num_computers", "computer_usage_hrs_per_day",
    ]
    data = {f: row[f] for f in fields}
    response["record"] = data
    return {"appliance_inventory": response}


@tool
def get_building_envelope(row_index: int) -> dict:
    """Task 4 — Assess building envelope: insulation quality, window type, roof type."""

    response = loadHousehold(row_index)
    if response["status"] != "SUCCESS":
        return {"building_envelope": response}

    row = response["record"]
    fields = ["insulation_quality", "window_type", "roof_type"]
    data = {f: row[f] for f in fields}
    response["record"] = data
    return {"building_envelope": response}


@tool
def get_renewable_assets(row_index: int) -> dict:
    """Task 5 — Check renewable assets: solar panels, solar capacity, battery storage, battery capacity."""

    response = loadHousehold(row_index)
    if response["status"] != "SUCCESS":
        return {"renewable_assets": response}

    row = response["record"]
    fields = [
        "has_solar_panels", "solar_capacity_kWp",
        "has_battery_storage", "battery_capacity_kWh",
    ]
    data = {f: row[f] for f in fields}
    response["record"] = data
    return {"renewable_assets": response}


tools = [
    find_row_indexes,
    get_household_profile,
    get_occupancy_details,
    get_appliance_inventory,
    get_building_envelope,
    get_renewable_assets,
]

system_prompt = """
You are a Household Energy data assistant.

You MUST use tools to answer household questions.

Rules:
- Never answer from your own knowledge.
- Households are identified by row_index (0 to 999) in the dataset.
- If the user gives a column filter (search_key and search_value) but not row_index:
  1. Call find_row_indexes with search_key and search_value
  2. Use a row_index from the result (e.g. the first one unless the user specifies another)
- If the user gives row_index directly, use it as given.
- For complete household input details (tasks 1 to 5), call all five data tools for the chosen row_index:
  get_household_profile, get_occupancy_details, get_appliance_inventory,
  get_building_envelope, get_renewable_assets
- After tool calls, summarize the records in plain language.
"""


def get_dataset() -> pd.DataFrame:
    """Return the loaded household energy dataset."""
    return _df.copy()


def run_agent(search_key: str, search_value: str) -> str:
    """Run the agent for the given search_key / search_value and return the final response text."""

    apikey = os.getenv("OPENAI_API_KEY", "test")
    llm = ChatOpenAI(api_key=apikey, temperature=0, model="gpt-4o-mini")
    agent = create_agent(model=llm, tools=tools, system_prompt=system_prompt)

    response = agent.invoke({
        "messages": [{
            "role": "user",
            "content": (
                f"Find row indexes where {search_key} = '{search_value}', then fetch "
                f"complete household input details for the first match (profile, occupancy, "
                f"appliances, building envelope, and renewable assets)."
            ),
        }]
    })
    return response["messages"][-1].content


if __name__ == "__main__":
    search_key = "house_type"
    search_value = "Apartment"

    print(f"Dataset: {len(_df)} households from {DATA_PATH.name}\n")
    print(run_agent(search_key, search_value))
