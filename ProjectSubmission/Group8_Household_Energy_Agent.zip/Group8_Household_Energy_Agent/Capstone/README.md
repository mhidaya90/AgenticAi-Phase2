# Household Energy Advisor

Capstone project for **Agentic AI** — an LLM-powered assistant that reads household energy data from a CSV dataset and returns structured household input details through tool-based agent execution.

Use case definition: `capstone2_household_energy.docx`

---

## Overview

This application helps explore **1,000 Indian household profiles** spanning house types, climate zones, city tiers, appliances, building characteristics, and renewable assets. Instead of hardcoding a single row, users can **search by any CSV column** (`search_key` + `search_value`), and the agent resolves matching rows and fetches full household details.

The design is based out of following pattern: (LangChain tools + `create_agent` + system prompt) and the Streamlit launch pattern from `../day1 day2/foundational_capabilities/`.

---

## What Has Been Implemented

| Area | Description |
|------|-------------|
| **Data source** | Direct CSV load via pandas |
| **Use case tasks** | Tasks **1–5** from the capstone document (data collection only) |
| **Generic search** | `find_row_indexes(search_key, search_value)` filters on any column |
| **Agent tools** | Six LangChain tools wired to an OpenAI LLM (`gpt-4o-mini`) |
| **CLI mode** | Run `household_energy_agent.py` directly from the terminal |
| **Streamlit UI** | Two-tab web app: **Dataset** (browse CSV) and **Agent** (search + results) |

### Use case tasks covered

| Task | Description | Tool |
|------|-------------|------|
| 1 | Collect household profile | `get_household_profile` |
| 2 | Capture occupancy details | `get_occupancy_details` |
| 3 | Inventory appliances | `get_appliance_inventory` |
| 4 | Assess building envelope | `get_building_envelope` |
| 5 | Check renewable energy assets | `get_renewable_assets` |
| — | Generic row lookup | `find_row_indexes` |

---

## Project Structure

```
Capstone/
├── README.md                          # This file
├── capstone2_household_energy.docx    # Use case specification
├── household_energy_requirement.csv   # Dataset (1000 rows, 47 columns)
├── household_energy_agent.py          # Agent logic, tools, and run_agent()
├── main.py                            # Streamlit UI entry point
└── run.bat                            # Launches Streamlit server
```

---

## Architecture

```
User (Streamlit or CLI)
        │
        ▼
   run_agent(search_key, search_value)
        │
        ▼
   LangChain Agent (gpt-4o-mini)
        │
        ├── find_row_indexes          → filter CSV by column
        ├── get_household_profile     → Task 1
        ├── get_occupancy_details     → Task 2
        ├── get_appliance_inventory   → Task 3
        ├── get_building_envelope     → Task 4
        └── get_renewable_assets      → Task 5
        │
        ▼
   Natural language summary (final response)
```

- **LLM**: Decides which tools to call and summarizes results.
- **Tools**: Read real data from the CSV — no fabricated values.
- **LoadHousehold()**: Internal helper (similar to `ExecuteQuery` in the medical sample).

---

## Dataset

**File:** `household_energy_requirement.csv`

| Attribute | Value |
|-----------|--------|
| Rows | 1,000 households |
| Columns | 47 features |
| House types | Apartment, Row House, Independent House, Villa |
| Climate zones | Hot & Humid, Hot & Dry, Composite, Temperate, Cold |
| City tiers | Tier 1, Tier 2, Tier 3 |

Each row includes profile, occupancy, appliances, envelope, solar/battery fields, and precomputed consumption columns (`daily_energy_consumption_kWh`, etc.).

---

## Prerequisites

- Python 3.9+
- OpenAI API key

### Python packages

```bash
pip install pandas langchain langchain-openai streamlit
```

---

## Configuration

Set your OpenAI API key using one of:

1. Environment variable: `OPENAI_API_KEY`

The agent uses `gpt-4o-mini` with `temperature=0`.

---

## How to Run

### Option 1 — Streamlit UI (recommended)

From the `Use_case` folder:

```bash
run.bat
```

Or:

```bash
streamlit run main.py
```

**Dataset tab** — browse the full CSV in a scrollable table.

**Agent tab** — enter `search_key` and `search_value`, click **Search**, and view the agent’s summary.

Default example:

| search_key | search_value |
|------------|--------------|
| `house_type` | `Apartment` |

Other examples:

| search_key | search_value |
|------------|--------------|
| `climate_zone` | `Hot & Humid` |
| `city_tier` | `Tier 1` |
| `num_bedrooms` | `3` |
| `insulation_quality` | `Excellent` |

### Option 2 — Command line

```bash
python household_energy_agent.py
```

Runs with default `search_key = "house_type"` and `search_value = "Apartment"`. Edit those values at the bottom of `household_energy_agent.py` to try other filters.

---

## Agent Behavior

When a search is triggered, the agent:

1. Calls **`find_row_indexes`** with the given `search_key` and `search_value`
2. Selects the **first matching `row_index`** (0-based, 0–999)
3. Calls all **five data tools** for that row
4. Returns a **plain-language summary** of profile, occupancy, appliances, envelope, and renewables

The system prompt instructs the LLM to use tools only and not invent data.

---

## Key Functions (for integration)

| Function | Purpose |
|----------|---------|
| `get_dataset()` | Returns a copy of the loaded DataFrame |
| `run_agent(search_key, search_value)` | Runs the full agent flow and returns the final text response |

These are used by `main.py` for the Streamlit UI.

---
