# -*- coding: utf-8 -*-

import streamlit as st

import household_energy_agent as agent_module

st.set_page_config(page_title="Household Energy Advisor", layout="wide")

st.title("Household Energy Advisor")
st.caption("Capstone use case — dataset browse and agent search")

dataset_tab, agent_tab = st.tabs(["Dataset", "Agent"])

with dataset_tab:
    st.subheader("Household Energy Dataset")
    df = agent_module.get_dataset()
    st.write(
        f"**{len(df)}** households · **{len(df.columns)}** columns · "
    )
    st.dataframe(df, use_container_width=True, height=600)

with agent_tab:
    st.subheader("Agent Search")
    st.write(
        "Enter a column name and value to find matching households "
        "and fetch full details for the first match."
    )

    columns = agent_module.get_dataset().columns.tolist()

    col1, col2 = st.columns(2)
    with col1:
        search_key = st.text_input(
            "search_key", value="house_type", placeholder="e.g. house_type"
        )
    with col2:
        search_value = st.text_input(
            "search_value", value="Apartment", placeholder="e.g. Apartment"
        )

    with st.expander("Available columns"):
        st.write(columns)

    search_clicked = st.button("Search", type="primary")

    if search_clicked:
        if not search_key.strip() or not search_value.strip():
            st.warning("Please enter both search_key and search_value.")
        else:
            with st.spinner("Running agent..."):
                try:
                    result = agent_module.run_agent(
                        search_key.strip(), search_value.strip()
                    )
                    st.success("Search complete")
                    st.markdown(result)
                except Exception as e:
                    st.error(f"Agent run failed: {e}")
